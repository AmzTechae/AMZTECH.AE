import { blogPosts } from '@/data/blogData';
import { additionalBlogPosts } from '@/data/enhancedBlogData';
import { uaeServiceAreas, servicePages } from '@/data/seoData';

interface SitemapURL {
  loc: string;
  lastmod: string;
  changefreq: 'always' | 'hourly' | 'daily' | 'weekly' | 'monthly' | 'yearly' | 'never';
  priority: number;
}

export const generateSitemap = (): string => {
  const baseUrl = 'https://amztech.ae';
  const today = new Date().toISOString().split('T')[0];
  
  const urls: SitemapURL[] = [];

  // Main pages
  const mainPages = [
    { path: '/', priority: 1.0, changefreq: 'daily' as const },
    { path: '/about', priority: 0.8, changefreq: 'monthly' as const },
    { path: '/sample-builds', priority: 0.9, changefreq: 'weekly' as const },
    { path: '/blog', priority: 0.8, changefreq: 'daily' as const },
    { path: '/contact', priority: 0.9, changefreq: 'monthly' as const },
  ];

  mainPages.forEach(page => {
    urls.push({
      loc: `${baseUrl}${page.path}`,
      lastmod: today,
      changefreq: page.changefreq,
      priority: page.priority
    });
  });

  // Blog posts
  const allBlogPosts = [...blogPosts, ...additionalBlogPosts];
  allBlogPosts.forEach(post => {
    urls.push({
      loc: `${baseUrl}/blog/${post.slug}`,
      lastmod: post.date,
      changefreq: 'monthly',
      priority: post.featured ? 0.8 : 0.6
    });
  });

  // Service Areas page
  urls.push({
    loc: `${baseUrl}/service-areas`,
    lastmod: today,
    changefreq: 'weekly',
    priority: 0.8
  });

  // Service pages
  servicePages.forEach(service => {
    urls.push({
      loc: `${baseUrl}/services/${service.slug}`,
      lastmod: today,
      changefreq: 'weekly',
      priority: 0.8
    });
  });

  // Generate XML
  const xmlContent = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urls.map(url => `  <url>
    <loc>${url.loc}</loc>
    <lastmod>${url.lastmod}</lastmod>
    <changefreq>${url.changefreq}</changefreq>
    <priority>${url.priority}</priority>
  </url>`).join('\n')}
</urlset>`;

  return xmlContent;
};

// Function to save sitemap (would typically be called during build process)
export const saveSitemap = () => {
  const sitemapContent = generateSitemap();
  
  // In a real application, you would save this to public/sitemap.xml
  // For now, we'll just log it or make it available for download
  console.log('Generated sitemap:', sitemapContent);
  
  return sitemapContent;
};

// Generate robots.txt content
export const generateRobotsTxt = (): string => {
  const baseUrl = 'https://amztech.ae';
  
  return `User-agent: *
Allow: /

# Allow all major search engines
User-agent: Googlebot
Allow: /

User-agent: Bingbot
Allow: /

User-agent: Slurp
Allow: /

User-agent: DuckDuckBot
Allow: /

User-agent: Baiduspider
Allow: /

User-agent: YandexBot
Allow: /

User-agent: facebookexternalhit
Allow: /

User-agent: Twitterbot
Allow: /

User-agent: LinkedInBot
Allow: /

User-agent: WhatsApp
Allow: /

# Disallow admin areas (if any)
Disallow: /admin/
Disallow: /api/
Disallow: /*.json$

# Sitemap location
Sitemap: ${baseUrl}/sitemap.xml

# Crawl delay for respectful crawling
Crawl-delay: 1

# Host directive
Host: ${baseUrl}`;
};