// UAE-wide service area data for local SEO
export const uaeServiceAreas = [
  {
    name: "Dubai",
    slug: "dubai",
    coordinates: { lat: 25.2048, lng: 55.2708 },
    description: "Custom gaming PC builds across Dubai emirate. Serving all areas including Downtown, Marina, JBR, Business Bay, and International City with premium PC building services.",
    keywords: "Gaming PC Dubai, Custom PC Dubai UAE, PC Builder Dubai Emirates",
    areas: ["Dubai Marina", "Downtown Dubai", "Business Bay", "JBR", "Dubai Internet City", "Deira", "Bur Dubai", "International City"],
    deliveryTime: "Next day (if ordered before 12pm)"
  },
  {
    name: "Abu Dhabi",
    slug: "abu-dhabi", 
    coordinates: { lat: 24.4539, lng: 54.3773 },
    description: "Professional gaming PC builds in Abu Dhabi emirate. Complete coverage of Abu Dhabi city, Al Ain, and surrounding areas with expert PC assembly services.",
    keywords: "Gaming PC Abu Dhabi, Custom PC Abu Dhabi UAE, PC Builder Capital UAE",
    areas: ["Abu Dhabi City", "Al Ain", "Ruwais", "Madinat Zayed", "Liwa Oasis"],
    deliveryTime: "2-3 days"
  },
  {
    name: "Sharjah", 
    slug: "sharjah",
    coordinates: { lat: 25.3463, lng: 55.4209 },
    description: "Custom gaming PC builds in Sharjah emirate. Serving Sharjah city, University City, and industrial areas with reliable PC building services.",
    keywords: "Gaming PC Sharjah, Custom PC Sharjah UAE, PC Builder Sharjah Emirates",
    areas: ["Sharjah City", "University City", "Industrial Area", "Al Qasimia", "Khorfakkan"],
    deliveryTime: "Next day (if ordered before 12pm)"
  },
  {
    name: "Ajman",
    slug: "ajman",
    coordinates: { lat: 25.4052, lng: 55.5136 },
    description: "Gaming PC building services in Ajman emirate. Professional PC builds for Ajman city and surrounding communities.",
    keywords: "Gaming PC Ajman, Custom PC Ajman UAE, PC Builder Ajman Emirates", 
    areas: ["Ajman City", "Al Nuaimiya", "Al Rashidiya", "Masfout"],
    deliveryTime: "Next day (if ordered before 12pm)"
  },
  {
    name: "Ras Al Khaimah",
    slug: "ras-al-khaimah",
    coordinates: { lat: 25.7889, lng: 55.9758 },
    description: "Custom gaming PC builds in Ras Al Khaimah emirate. Serving RAK city and northern UAE areas with expert PC assembly.",
    keywords: "Gaming PC RAK, Custom PC Ras Al Khaimah, PC Builder Northern UAE",
    areas: ["RAK City", "Julfar", "Al Hamra", "Al Jazirah Al Hamra", "Digdaga"],
    deliveryTime: "2-3 days"
  },
  {
    name: "Fujairah",
    slug: "fujairah",
    coordinates: { lat: 25.1164, lng: 56.3265 },
    description: "Gaming PC builds in Fujairah emirate. Professional PC building services for east coast UAE communities.",
    keywords: "Gaming PC Fujairah, Custom PC East Coast UAE, PC Builder Fujairah Emirates",
    areas: ["Fujairah City", "Khor Fakkan", "Kalba", "Dibba Al-Fujairah", "Masafi"],
    deliveryTime: "2-3 days"
  },
  {
    name: "Umm Al Quwain",
    slug: "umm-al-quwain", 
    coordinates: { lat: 25.5641, lng: 55.6550 },
    description: "Custom gaming PC builds in Umm Al Quwain emirate. Comprehensive PC building services for UAQ and surrounding areas.",
    keywords: "Gaming PC UAQ, Custom PC Umm Al Quwain, PC Builder UAQ Emirates",
    areas: ["UAQ City", "Falaj Al Mualla", "Al Dur", "Al Salam City"],
    deliveryTime: "2-3 days"
  }
];

// Service-specific SEO data
export const servicePages = [
  {
    title: "Budget Gaming PC Builds Under 3000 AED Dubai | AMZ TECH",
    slug: "budget-gaming-pc-builds",
    description: "Affordable custom gaming PC builds under 3000 AED in Dubai. Perfect for 1080p gaming with AMD Ryzen and GTX/RTX graphics cards. Free assembly and delivery.",
    keywords: "Budget Gaming PC Dubai, Cheap Gaming PC UAE, Gaming PC Under 3000 AED, Affordable PC Build Dubai",
    content: "Budget gaming PC builds that deliver excellent 1080p gaming performance without breaking the bank.",
    price: "2000-3500 AED"
  },
  {
    title: "Mid-Range Gaming PC Builds 4000-8000 AED Dubai | AMZ TECH",
    slug: "mid-range-gaming-pc-builds",
    description: "Balanced mid-range gaming PC builds 4000-8000 AED in Dubai. Perfect for 1440p gaming, streaming, and content creation with RTX 4060/4070 graphics.",
    keywords: "Mid Range Gaming PC Dubai, 1440p Gaming PC UAE, RTX 4060 PC Build Dubai, Gaming PC 5000 AED",
    content: "Mid-range gaming PCs that offer the perfect balance of performance and value for 1440p gaming.",
    price: "4000-8000 AED"
  },
  {
    title: "High-End Gaming PC Builds RTX 4080/4090 Dubai | AMZ TECH",
    slug: "high-end-gaming-pc-builds",
    description: "Premium high-end gaming PC builds with RTX 4080/4090 in Dubai. 4K gaming, ray tracing, and professional workstation capabilities. Expert assembly included.",
    keywords: "High End Gaming PC Dubai, RTX 4090 PC Build UAE, 4K Gaming PC Dubai, Premium PC Build UAE",
    content: "High-end gaming PCs built for enthusiasts who demand the ultimate performance for 4K gaming and professional work.",
    price: "8000-20000 AED"
  },
  {
    title: "RGB Gaming PC Builds with Custom Lighting Dubai | AMZ TECH",
    slug: "rgb-gaming-pc-builds",
    description: "Custom RGB gaming PC builds with stunning lighting effects in Dubai. Corsair iCUE, ASUS Aura Sync, and custom water cooling with RGB. Show-stopping builds.",
    keywords: "RGB Gaming PC Dubai, Custom RGB PC UAE, Gaming PC Lighting Dubai, RGB PC Build UAE",
    content: "RGB gaming PCs that combine high performance with stunning visual appeal and synchronized lighting effects.",
    price: "5000-15000 AED"
  }
];

// Blog categories with SEO focus
export const blogCategories = [
  {
    name: "Gaming PC Builds",
    slug: "gaming-pc-builds",
    description: "Complete gaming PC build guides, component recommendations, and build tutorials for all budgets in Dubai UAE.",
    keywords: "Gaming PC Build Guide Dubai, PC Build Tutorial UAE, Custom PC Assembly Dubai"
  },
  {
    name: "Component Reviews",
    slug: "component-reviews",
    description: "In-depth reviews of the latest PC components available in Dubai - GPUs, CPUs, motherboards, and more.",
    keywords: "PC Component Reviews Dubai, GPU Review UAE, CPU Benchmark Dubai, Motherboard Review UAE"
  },
  {
    name: "Gaming News",
    slug: "gaming-news",
    description: "Latest gaming industry news, new PC component releases, and gaming trends relevant to UAE gamers.",
    keywords: "Gaming News UAE, PC Gaming News Dubai, Gaming Industry UAE, Gaming Trends Dubai"
  },
  {
    name: "Buying Guides",
    slug: "buying-guides",
    description: "Comprehensive buying guides for PC components and gaming accessories available in Dubai and UAE markets.",
    keywords: "PC Buying Guide Dubai, Gaming PC Buying Guide UAE, Component Buying Guide Dubai"
  },
  {
    name: "Tutorials",
    slug: "tutorials",
    description: "Step-by-step tutorials for PC building, troubleshooting, and optimization for Dubai gamers.",
    keywords: "PC Build Tutorial Dubai, Gaming PC Tutorial UAE, PC Assembly Guide Dubai"
  }
];

// FAQ data with schema markup
export const faqData = [
  {
    question: "How much does a custom gaming PC build cost in UAE?",
    answer: "Gaming PC builds in UAE range from 2000 AED for budget builds to 20000+ AED for high-end systems. Mid-range builds (4000-8000 AED) offer the best value for 1440p gaming. Prices are consistent across all emirates.",
    keywords: "Gaming PC price UAE, Custom PC cost Dubai Abu Dhabi, PC build cost UAE"
  },
  {
    question: "Do you provide warranty on custom gaming PC builds?",
    answer: "Yes, we provide comprehensive 360° warranty on all custom gaming PC builds throughout UAE. Component warranties range from 1-5 years depending on the manufacturer, and we offer 1 year service warranty nationwide.",
    keywords: "Gaming PC warranty UAE, PC build warranty Dubai Abu Dhabi, Custom PC guarantee UAE"
  },
  {
    question: "How long does it take to build and deliver a gaming PC across UAE?",
    answer: "After payment, we need 24 hours to make your gaming PC setup ready. For basic builds: Dubai, Sharjah, and Ajman get next-day delivery if ordered before 12pm. Other emirates (Abu Dhabi, RAK, Fujairah, UAQ) receive delivery in 2-3 days. Any changes to basic builds will be communicated before confirmation.",
    keywords: "PC build time UAE, Custom PC delivery UAE, Gaming PC assembly time Emirates"
  },
  {
    question: "Do you deliver gaming PCs to all UAE emirates?",
    answer: "Yes, we provide delivery across all seven UAE emirates. Dubai, Sharjah, and Ajman get next-day delivery (if ordered before 12pm). Abu Dhabi, Ras Al Khaimah, Fujairah, and Umm Al Quwain receive delivery within 2-3 days. All PCs are ready for setup within 24 hours of payment.",
    keywords: "Gaming PC delivery UAE, PC build delivery Emirates, Custom PC shipping UAE nationwide"
  },
  {
    question: "Can you help me choose the right components for my gaming PC?",
    answer: "Absolutely! Our experts provide free consultation via WhatsApp, phone, or video call to help you choose the perfect components based on your budget, gaming preferences, and performance requirements, regardless of your location in UAE.",
    keywords: "PC component consultation UAE, Gaming PC advice Emirates, PC build consultation Dubai Abu Dhabi"
  },
  {
    question: "What areas do you serve in UAE?",
    answer: "We serve all seven UAE emirates with comprehensive coverage. Dubai, Sharjah, and Ajman get next-day delivery (if ordered before 12pm). Abu Dhabi, Ras Al Khaimah, Fujairah, and Umm Al Quwain receive delivery within 2-3 days. We cover major cities and remote areas alike.",
    keywords: "UAE gaming PC service areas, Emirates PC delivery coverage, Gaming PC UAE nationwide service"
  }
];

// Meta descriptions for different page types
export const metaDescriptions = {
  home: "AMZ TECH - UAE's premier custom gaming PC builder. Professional PC builds with 360° warranty, nationwide delivery, and best market prices. Serving all 7 emirates!",
  about: "Learn about AMZ TECH - UAE's trusted gaming PC building experts. Professional team with years of experience building custom gaming PCs across all Emirates.",
  contact: "Contact AMZ TECH for custom gaming PC builds across UAE. Get free quotes, expert consultation, and professional PC building services. Serving all Emirates!",
  blog: "AMZ TECH Gaming PC Blog - Latest guides, reviews, and tutorials for custom gaming PC builds in UAE. Expert advice for gamers across all Emirates.",
  sampleBuilds: "Explore our sample gaming PC builds for all budgets across UAE. Budget, mid-range, and high-end builds with detailed specifications and Emirates-wide delivery.",
  serviceAreas: "AMZ TECH serves all UAE Emirates with custom gaming PC builds. Dubai, Abu Dhabi, Sharjah, Ajman, RAK, Fujairah, UAQ - professional PC building nationwide."
};

// Canonical URL patterns
export const getCanonicalUrl = (path: string): string => {
  const baseUrl = "https://amztech.ae";
  return `${baseUrl}${path}`;
};