// Import images for blog posts
import heroImage from '@/assets/hero-gaming-setup.jpg';
import highendBuild from '@/assets/highend-pc-build.jpg';
import workspaceImage from '@/assets/pc-building-workspace.jpg';

export interface BlogPost {
  id: number;
  title: string;
  excerpt: string;
  content: string;
  slug: string;
  image: string;
  author: string;
  date: string;
  readTime: string;
  category: string;
  featured?: boolean;
  tags: string[];
  metaDescription: string;
}

export const blogPosts: BlogPost[] = [
  {
    id: 1,
    title: "Why a Custom Gaming PC Outperforms Pre-Built Systems in 2025",
    excerpt: "When it comes to gaming, your hardware can mean the difference between smooth, immersive gameplay and frustrating lag spikes. Discover why custom builds win every single time.",
    slug: "custom-gaming-pc-outperforms-prebuilt-2025",
    content: `
      <h2>Introduction</h2>
      <p>When it comes to gaming, your hardware can mean the difference between smooth, immersive gameplay and frustrating lag spikes. Many gamers debate between buying a pre-built gaming PC or going for a custom-built system. At AMZ Tech, we've seen firsthand why custom builds win every single time.</p>
      
      <h3>1. Performance Tailored to Your Needs</h3>
      <p>Prebuilt PCs are built to appeal to the average gamer, but gaming isn't average. Maybe you're into esports titles that rely on high frame rates, or AAA open-world games that demand massive GPU power. With a custom PC, every component is chosen with your gaming style in mind.</p>
      
      <h3>2. Superior Cooling & Airflow</h3>
      <p>One of the biggest killers of performance? Overheating. Prebuilt systems often cut corners with cooling solutions. Custom rigs, on the other hand, can be equipped with liquid cooling, optimized case airflow, and high-end fans to ensure stable performance during marathon sessions.</p>
      
      <h3>3. Upgrade-Friendly Futureproofing</h3>
      <p>Gaming evolves fast. Prebuilt PCs often use proprietary parts that make upgrades expensive or even impossible. A custom build from AMZ Tech ensures that every component can be swapped, upgraded, or scaled — meaning your system grows with you.</p>
      
      <h3>4. Better Value Over Time</h3>
      <p>Prebuilts may seem cheaper upfront, but hidden costs like weak power supplies, locked motherboards, and overpriced warranties add up. Custom builds deliver more value for your money and last longer without needing total replacement.</p>
      
      <h3>5. Personalization & Style</h3>
      <p>Custom rigs aren't just powerful — they look the part. Whether you want RGB lighting, glass panels, or a sleek minimalist build, customization means your PC reflects you.</p>
      
      <h3>Conclusion</h3>
      <p>At AMZ Tech, we build gaming PCs that deliver unmatched performance, style, and longevity. Don't settle for average.</p>
      <p><strong>👉 Explore our custom gaming PC builds today and unlock your true gaming potential.</strong></p>
    `,
    image: heroImage,
    author: "AMZ TECH Team",
    date: "2025-01-15",
    readTime: "6 min read",
    category: "Guides",
    featured: true,
    tags: ["Custom Gaming PC", "Prebuilt vs Custom", "Best Gaming Performance", "2025"],
    metaDescription: "Discover why custom gaming PCs deliver better performance, cooling, and value than prebuilt systems in 2025. Build your dream PC with AMZ Tech today."
  },
  {
    id: 2,
    title: "The Top 5 Mistakes Gamers Make When Buying a PC (and How to Avoid Them)",
    excerpt: "Buying a gaming PC can be overwhelming — with so many specs, parts, and flashy marketing terms, it's easy to make mistakes that hurt your wallet and performance.",
    slug: "top-5-gaming-pc-buying-mistakes-2025",
    content: `
      <h2>Introduction</h2>
      <p>Buying a gaming PC can be overwhelming — with so many specs, parts, and flashy marketing terms, it's easy to make mistakes that hurt your wallet and performance. Here are the top 5 pitfalls gamers fall into, and how AMZ Tech helps you avoid them.</p>
      
      <h3>Mistake 1: Paying for Branding, Not Performance</h3>
      <p>Some prebuilt companies charge premium prices just for a brand name, even when the hardware is outdated or underpowered.</p>
      <p><strong>✅ Solution:</strong> At AMZ Tech, we focus on raw performance, not hype. Every dollar goes into better components.</p>
      
      <h3>Mistake 2: Choosing RGB Over Hardware</h3>
      <p>Sure, RGB lighting looks cool, but performance should come first. Many gamers spend too much on aesthetics and too little on CPUs or GPUs.</p>
      <p><strong>✅ Solution:</strong> We balance both — powerful rigs with style that doesn't compromise performance.</p>
      
      <h3>Mistake 3: Ignoring Upgradability</h3>
      <p>Buying a PC that can't be upgraded means you'll be forced to replace it sooner.</p>
      <p><strong>✅ Solution:</strong> AMZ Tech ensures all builds use upgrade-friendly parts so your rig evolves with you.</p>
      
      <h3>Mistake 4: Skipping Proper Cooling</h3>
      <p>Overheating destroys performance and lifespan.</p>
      <p><strong>✅ Solution:</strong> Every AMZ Tech build includes optimized airflow and premium cooling options.</p>
      
      <h3>Mistake 5: No Warranty or After-Sales Support</h3>
      <p>Many buyers forget to check support and warranty — until it's too late.</p>
      <p><strong>✅ Solution:</strong> Our builds come with peace of mind — warranty, support, and upgrade consultation.</p>
      
      <h3>Conclusion</h3>
      <p>Don't fall into these traps when buying a gaming PC.</p>
      <p><strong>👉 Trust AMZ Tech to build your dream PC — optimized, upgradeable, and reliable.</strong></p>
    `,
    image: workspaceImage,
    author: "AMZ TECH Team",
    date: "2025-01-10",
    readTime: "5 min read",
    category: "Guides",
    tags: ["Gaming PC Mistakes", "Buying a Gaming PC", "Custom PC Tips", "2025"],
    metaDescription: "Don't waste money on the wrong gaming PC! Learn the top 5 mistakes buyers make in 2025 and how AMZ Tech helps you build the perfect custom rig."
  },
  {
    id: 3,
    title: "Gaming PC vs Gaming Laptop: Which One Should You Buy in 2025?",
    excerpt: "It's 2025, and both gaming desktops and laptops are more powerful than ever. But when it comes to performance, longevity, and value, which is the better investment?",
    slug: "gaming-pc-vs-laptop-2025-comparison",
    content: `
      <h2>Introduction</h2>
      <p>It's 2025, and both gaming desktops and laptops are more powerful than ever. But when it comes to performance, longevity, and value, which is the better investment? Let's break it down.</p>
      
      <h3>1. Performance</h3>
      <p>Desktops still dominate when it comes to raw power. With larger GPUs, better cooling, and customizable setups, desktops outperform laptops in high-demand games.</p>
      
      <h3>2. Portability</h3>
      <p>Gaming laptops are unbeatable for travel, college, or gaming on the go. But that convenience comes with trade-offs: limited cooling, battery life issues, and weaker performance per dollar.</p>
      
      <h3>3. Price-to-Performance</h3>
      <p>Dollar for dollar, desktops deliver significantly more power. A $2,000 custom desktop outperforms a $2,500 laptop by a wide margin.</p>
      
      <h3>4. Upgradeability</h3>
      <p>Desktops win again. With a custom rig, you can upgrade your GPU, CPU, or storage anytime. Laptops are mostly locked, forcing complete replacement after a few years.</p>
      
      <h3>5. Longevity & Repairs</h3>
      <p>Desktops last longer and are easier (and cheaper) to repair. Laptops are compact but harder to service.</p>
      
      <h3>Conclusion</h3>
      <p>Both have their place, but if you want maximum gaming performance, upgrade flexibility, and long-term value, a custom gaming PC is the way to go.</p>
      <p><strong>👉 At AMZ Tech, we'll build you a rig that beats any laptop in power and longevity.</strong></p>
    `,
    image: highendBuild,
    author: "AMZ TECH Team",
    date: "2025-01-05",
    readTime: "6 min read",
    category: "Comparison",
    tags: ["Gaming Laptop vs Desktop", "Best Gaming PC 2025", "Custom Gaming Rigs"],
    metaDescription: "Thinking of buying a gaming laptop or desktop in 2025? Compare performance, value, and upgradeability to see why AMZ Tech custom PCs win every time."
  },
  {
    id: 4,
    title: "How to Choose the Best Components for Your Gaming PC in 2025",
    excerpt: "Building a gaming PC in 2025 means choosing from hundreds of CPUs, GPUs, and accessories. But which components really matter for your setup?",
    slug: "best-gaming-pc-components-2025-guide",
    content: `
      <h2>Introduction</h2>
      <p>Building a gaming PC in 2025 means choosing from hundreds of CPUs, GPUs, and accessories. But which components really matter for your setup? Here's a breakdown to help you make the best choices.</p>
      
      <h3>Key Components to Focus On:</h3>
      
      <h4>CPU – The brain of your PC</h4>
      <p>Intel i9 14900K and Ryzen 9 7950X3D are top picks for 2025.</p>
      
      <h4>GPU – The most critical part for gaming</h4>
      <p>RTX 4090 leads the pack, but RTX 4070 Ti is great for mid-range builds.</p>
      
      <h4>RAM – At least 32GB DDR5</h4>
      <p>Modern AAA titles and multitasking demand more memory than ever.</p>
      
      <h4>Storage – NVMe SSDs for fast load times</h4>
      <p>1TB minimum recommended for your game library.</p>
      
      <h4>Cooling – Liquid cooling for high-end builds</h4>
      <p>Advanced air cooling works great for budget-friendly setups.</p>
      
      <h4>Motherboard & PSU – Don't skimp</h4>
      <p>Stability and power delivery are crucial for consistent performance.</p>
      
      <h3>Component Compatibility Tips</h3>
      <ul>
        <li>Ensure your motherboard supports your chosen CPU socket</li>
        <li>Check PSU wattage requirements for your GPU</li>
        <li>Verify RAM compatibility with your motherboard</li>
        <li>Consider case size for your components</li>
      </ul>
      
      <h3>Conclusion</h3>
      <p>Picking the right components ensures a smooth gaming experience for years to come.</p>
      <p><strong>👉 Let AMZ Tech handle the hassle — we'll design the perfect combination for your budget and gaming style.</strong></p>
    `,
    image: workspaceImage,
    author: "AMZ TECH Team",
    date: "2025-01-01",
    readTime: "8 min read",
    category: "Hardware",
    tags: ["Best PC Components 2025", "Gaming PC Parts", "Custom PC Build Guide"],
    metaDescription: "From CPU and GPU to cooling and storage, discover the best gaming PC components for 2025. Let AMZ Tech build your perfect custom gaming setup."
  },
  {
    id: 5,
    title: "The Future of Gaming PCs: Trends to Watch in 2025 and Beyond",
    excerpt: "The gaming world is evolving fast. From AI-driven graphics to cloud integration, the future of gaming PCs looks more exciting than ever.",
    slug: "future-gaming-pc-trends-2025-beyond",
    content: `
      <h2>Introduction</h2>
      <p>The gaming world is evolving fast. From AI-driven graphics to cloud integration, the future of gaming PCs looks more exciting than ever. Here are the biggest trends shaping gaming rigs in 2025.</p>
      
      <h3>Key Trends</h3>
      
      <h4>AI-Enhanced Gaming</h4>
      <p>GPUs like NVIDIA RTX 5000 series (coming soon) will leverage AI for real-time rendering, upscaling, and frame generation beyond what we see today.</p>
      
      <h4>Liquid-Cooled Everything</h4>
      <p>Even mid-range builds now use hybrid cooling systems, making liquid cooling more accessible and efficient than ever.</p>
      
      <h4>Smaller but Stronger PCs</h4>
      <p>Mini-ITX builds are gaining popularity without sacrificing power, perfect for space-conscious gamers.</p>
      
      <h4>4K & 8K Gaming</h4>
      <p>Monitors and GPUs are pushing boundaries, making high-resolution gaming mainstream.</p>
      
      <h4>VR & AR Ready PCs</h4>
      <p>Custom rigs designed for immersive next-gen experiences, with specialized cooling and performance optimization.</p>
      
      <h3>Technology Innovations</h3>
      <ul>
        <li>DDR5 becomes the standard across all price ranges</li>
        <li>PCIe 5.0 SSDs deliver unprecedented storage speeds</li>
        <li>CPU architectures focus on efficiency and gaming performance</li>
        <li>Modular PC designs allow easier upgrades</li>
      </ul>
      
      <h3>What This Means for Gamers</h3>
      <p>These trends point to more powerful, efficient, and customizable gaming experiences. The key is building a system that can adapt to these evolving technologies.</p>
      
      <h3>Conclusion</h3>
      <p>Gaming PCs aren't just evolving — they're becoming the centerpiece of entertainment and productivity.</p>
      <p><strong>👉 Stay ahead of the curve with an AMZ Tech build that's future-proof and ready for tomorrow's games.</strong></p>
    `,
    image: heroImage,
    author: "AMZ TECH Team",
    date: "2024-12-28",
    readTime: "7 min read",
    category: "Technology",
    tags: ["Future of Gaming PCs", "Gaming Trends 2025", "Custom PC Technology"],
    metaDescription: "Stay ahead of the curve! Explore the latest 2025 gaming PC trends, from AI-powered graphics to 8K gaming, with AMZ Tech custom-built PCs."
  }
];

export const categories = ["All", "Guides", "Hardware", "Comparison", "Technology"];

export const formatDate = (dateString: string) => {
  const date = new Date(dateString);
  return date.toLocaleDateString('en-US', { 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  });
};

export const getBlogPostBySlug = (slug: string): BlogPost | undefined => {
  return blogPosts.find(post => post.slug === slug);
};

export const getRelatedPosts = (currentPost: BlogPost, limit: number = 3): BlogPost[] => {
  return blogPosts
    .filter(post => post.id !== currentPost.id && post.category === currentPost.category)
    .slice(0, limit);
};