import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import amzLogo from '@/assets/amz-logo.png';

const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  const navItems = [
    { name: 'Home', path: '/' },
    { name: 'About', path: '/about' },
    { name: 'Sample Builds', path: '/sample-builds' },
    { name: 'Service Areas', path: '/service-areas' },
    { name: 'Blog', path: '/blog' },
    { name: 'Contact', path: '/contact' },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/90 backdrop-blur-md border-b border-border">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-3 flex-shrink-0">
            <img src={amzLogo} alt="AMZ TECH" className="h-8 sm:h-10 w-auto" />
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-6 lg:space-x-8 xl:space-x-10">
            {navItems.map((item) => (
              <Link
                key={item.name}
                to={item.path}
                className={`text-sm lg:text-base font-medium transition-colors duration-200 whitespace-nowrap ${
                  isActive(item.path)
                    ? 'text-primary font-semibold'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                {item.name}
              </Link>
            ))}
          </div>

          {/* Desktop CTA Buttons */}
          <div className="hidden lg:flex items-center space-x-3 lg:space-x-4 flex-shrink-0">
            <a 
              href="https://api.whatsapp.com/send?phone=971564689006" 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center text-xs lg:text-sm text-muted-foreground hover:text-primary transition-colors whitespace-nowrap px-2 py-1 rounded-md hover:bg-accent"
            >
              <MessageCircle className="w-3 h-3 lg:w-4 lg:h-4 mr-1 lg:mr-2" />
              WhatsApp
            </a>
            <Button variant="gaming" size="sm" className="text-xs lg:text-sm px-3 lg:px-4" asChild>
              <Link to="/contact">Get Quote</Link>
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="lg:hidden mobile-nav-button text-foreground hover:text-primary hover:bg-accent"
            aria-label="Toggle navigation menu"
          >
            {isOpen ? <X className="w-7 h-7" /> : <Menu className="w-7 h-7" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="lg:hidden absolute top-16 lg:top-20 left-0 right-0 bg-background/85 backdrop-blur-md border-b border-border shadow-xl">
            <div className="mobile-container py-6 space-y-2">
              {navItems.map((item) => (
                <Link
                  key={item.name}
                  to={item.path}
                  onClick={() => setIsOpen(false)}
                  className={`mobile-nav-item ${
                    isActive(item.path)
                      ? 'text-primary font-semibold bg-primary/10 border-l-4 border-primary'
                      : 'text-muted-foreground hover:text-foreground hover:bg-accent'
                  }`}
                >
                  {item.name}
                </Link>
              ))}
              <div className="pt-6 space-y-4 border-t border-border mt-4">
                <a 
                  href="https://api.whatsapp.com/send?phone=971564689006" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center mobile-text-base text-muted-foreground hover:text-primary transition-colors touch-target"
                  onClick={() => setIsOpen(false)}
                >
                  <MessageCircle className="w-5 h-5 mr-3" />
                  WhatsApp Chat
                </a>
                <Button variant="gaming" className="w-full" asChild>
                  <Link to="/contact" onClick={() => setIsOpen(false)}>
                    Get Custom Quote
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navigation;