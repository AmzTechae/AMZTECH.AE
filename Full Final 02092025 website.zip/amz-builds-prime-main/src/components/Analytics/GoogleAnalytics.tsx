import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';

declare global {
  interface Window {
    gtag: (command: string, targetId: string, config?: any) => void;
    dataLayer: any[];
  }
}

interface GoogleAnalyticsProps {
  measurementId?: string;
}

const GoogleAnalytics = ({ measurementId = 'G-XXXXXXXXXX' }: GoogleAnalyticsProps) => {
  const location = useLocation();

  useEffect(() => {
    // Prevent script injection in development/testing environments
    if (measurementId === 'G-XXXXXXXXXX') return;

    // Load Google Analytics script with error handling
    const script1 = document.createElement('script');
    script1.async = true;
    script1.src = `https://www.googletagmanager.com/gtag/js?id=${measurementId}`;
    script1.onerror = () => console.warn('Failed to load GA script');
    
    const script2 = document.createElement('script');
    script2.innerHTML = `
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
      gtag('config', '${measurementId}', {
        page_title: document.title,
        page_location: window.location.href,
        custom_map: {
          'custom_dimension_1': 'user_type',
          'custom_dimension_2': 'page_category',
          'custom_dimension_3': 'content_group'
        }
      });
    `;
    
    document.head.appendChild(script1);
    document.head.appendChild(script2);

    return () => {
      try {
        if (document.head.contains(script1)) document.head.removeChild(script1);
        if (document.head.contains(script2)) document.head.removeChild(script2);
      } catch (error) {
        console.warn('Error removing GA scripts:', error);
      }
    };
  }, [measurementId]);

  // Track page views
  useEffect(() => {
    if (typeof window.gtag !== 'undefined') {
      window.gtag('config', measurementId, {
        page_path: location.pathname + location.search,
        page_title: document.title,
        page_location: window.location.href
      });
    }
  }, [location, measurementId]);

  return null;
};

// Custom event tracking functions
export const trackEvent = (eventName: string, parameters: Record<string, any> = {}) => {
  if (typeof window.gtag !== 'undefined') {
    window.gtag('event', eventName, {
      event_category: parameters.category || 'engagement',
      event_label: parameters.label,
      value: parameters.value,
      custom_parameter_1: parameters.custom1,
      custom_parameter_2: parameters.custom2,
      ...parameters
    });
  }
};

// Specific tracking functions for gaming PC website
export const trackQuoteRequest = (buildType: string, budget: string) => {
  trackEvent('quote_request', {
    category: 'conversion',
    label: buildType,
    value: budget,
    custom1: 'quote_form',
    build_type: buildType,
    budget_range: budget
  });
};

export const trackBlogRead = (articleTitle: string, category: string, readTime: number) => {
  trackEvent('article_read', {
    category: 'content',
    label: articleTitle,
    value: readTime,
    content_category: category,
    article_title: articleTitle
  });
};

export const trackComponentClick = (componentName: string, buildType: string) => {
  trackEvent('component_interest', {
    category: 'product',
    label: componentName,
    build_type: buildType,
    component_name: componentName
  });
};

export const trackContactAttempt = (method: string, page: string) => {
  trackEvent('contact_attempt', {
    category: 'lead',
    label: method,
    contact_method: method,
    source_page: page
  });
};

export const trackSampleBuildView = (buildName: string, price: string) => {
  trackEvent('sample_build_view', {
    category: 'product',
    label: buildName,
    value: price,
    build_name: buildName,
    price_range: price
  });
};

export const trackLocationInterest = (locationName: string) => {
  trackEvent('location_interest', {
    category: 'local',
    label: locationName,
    location_name: locationName
  });
};

export default GoogleAnalytics;