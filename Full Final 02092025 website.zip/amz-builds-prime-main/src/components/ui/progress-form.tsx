import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, CheckCircle, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';

interface FormData {
  fullName: string;
  phone: string;
  budgetRange: string;
  purpose: string;
  preferredCpu: string;
  preferredGpu: string;
  email: string;
  additionalNotes: string;
}

interface ProgressiveQuoteFormProps {
  onSubmit: (formData: FormData) => void;
}

export const ProgressiveQuoteForm: React.FC<ProgressiveQuoteFormProps> = ({ onSubmit }) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState<FormData>({
    fullName: '',
    phone: '',
    budgetRange: '',
    purpose: '',
    preferredCpu: '',
    preferredGpu: '',
    email: '',
    additionalNotes: ''
  });

  const totalSteps = 3;
  const progress = (currentStep / totalSteps) * 100;

  const handleInputChange = (field: keyof FormData, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const isStepValid = (step: number): boolean => {
    switch (step) {
      case 1:
        return !!(formData.fullName && formData.phone && formData.budgetRange && formData.purpose);
      case 2:
        return true; // Step 2 is optional
      case 3:
        return !!formData.email;
      default:
        return false;
    }
  };

  const nextStep = () => {
    if (currentStep < totalSteps && isStepValid(currentStep)) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isStepValid(3)) {
      onSubmit(formData);
    }
  };

  const getStepTitle = (step: number): string => {
    switch (step) {
      case 1: return "Basic Information";
      case 2: return "Technical Preferences";
      case 3: return "Contact & Finalize";
      default: return "";
    }
  };

  const getStepDescription = (step: number): string => {
    switch (step) {
      case 1: return "Tell us about yourself and your budget";
      case 2: return "Let us know your component preferences (optional)";
      case 3: return "Provide your email and any additional details";
      default: return "";
    }
  };

  return (
    <Card className="gaming-card">
      <CardHeader>
        <div className="flex items-center justify-between mb-4">
          <div>
            <CardTitle className="text-2xl text-neon">Get Your Custom PC Quote</CardTitle>
            <p className="text-sm text-muted-foreground mt-1">
              Step {currentStep} of {totalSteps}: {getStepTitle(currentStep)}
            </p>
          </div>
          <div className="text-right">
            <div className="text-sm text-muted-foreground">Progress</div>
            <div className="text-lg font-semibold text-primary">{Math.round(progress)}%</div>
          </div>
        </div>
        
        <div className="space-y-2">
          <Progress value={progress} className="h-2" />
          <p className="text-sm text-muted-foreground">
            {getStepDescription(currentStep)}
          </p>
        </div>
      </CardHeader>

      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Step 1: Basic Information */}
          {currentStep === 1 && (
            <div className="space-y-6 animate-fade-in">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="fullName">Full Name *</Label>
                  <Input
                    id="fullName"
                    value={formData.fullName}
                    onChange={(e) => handleInputChange('fullName', e.target.value)}
                    placeholder="Enter your full name"
                    required
                    className="bg-input border-border"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="phone">WhatsApp Number *</Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => handleInputChange('phone', e.target.value)}
                    placeholder="+971 50 123 4567"
                    required
                    className="bg-input border-border"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="budgetRange">Budget Range *</Label>
                  <Select value={formData.budgetRange} onValueChange={(value) => handleInputChange('budgetRange', value)}>
                    <SelectTrigger className="bg-input border-border">
                      <SelectValue placeholder="Select your budget range" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1800-3000">1,800 - 3,000 AED</SelectItem>
                      <SelectItem value="3000-5000">3,000 - 5,000 AED</SelectItem>
                      <SelectItem value="5000-8000">5,000 - 8,000 AED</SelectItem>
                      <SelectItem value="8000-12000">8,000 - 12,000 AED</SelectItem>
                      <SelectItem value="12000-plus">12,000+ AED</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="purpose">Primary Purpose *</Label>
                  <Select value={formData.purpose} onValueChange={(value) => handleInputChange('purpose', value)}>
                    <SelectTrigger className="bg-input border-border">
                      <SelectValue placeholder="Select primary use" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="gaming">Gaming</SelectItem>
                      <SelectItem value="video-editing">Video Editing</SelectItem>
                      <SelectItem value="3d-workstation">3D Workstation</SelectItem>
                      <SelectItem value="general-use">General Use</SelectItem>
                      <SelectItem value="streaming">Gaming & Streaming</SelectItem>
                      <SelectItem value="productivity">Productivity & Work</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="bg-primary/5 border border-primary/20 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <CheckCircle className="w-5 h-5 text-secondary" />
                  <span className="font-semibold text-secondary">Get Instant Estimate</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  Based on your budget and purpose, we'll provide an immediate price estimate in the next step!
                </p>
              </div>
            </div>
          )}

          {/* Step 2: Technical Preferences */}
          {currentStep === 2 && (
            <div className="space-y-6 animate-fade-in">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="preferredCpu">Preferred CPU Brand</Label>
                  <Select value={formData.preferredCpu} onValueChange={(value) => handleInputChange('preferredCpu', value)}>
                    <SelectTrigger className="bg-input border-border">
                      <SelectValue placeholder="Select CPU preference" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="intel">Intel</SelectItem>
                      <SelectItem value="amd">AMD</SelectItem>
                      <SelectItem value="no-preference">No Preference</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="preferredGpu">Preferred GPU Brand</Label>
                  <Select value={formData.preferredGpu} onValueChange={(value) => handleInputChange('preferredGpu', value)}>
                    <SelectTrigger className="bg-input border-border">
                      <SelectValue placeholder="Select GPU preference" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="nvidia">NVIDIA</SelectItem>
                      <SelectItem value="amd">AMD</SelectItem>
                      <SelectItem value="no-preference">No Preference</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Instant Estimate Display */}
              {formData.budgetRange && formData.purpose && (
                <div className="bg-gradient-to-r from-primary/10 to-secondary/10 border border-primary/30 rounded-lg p-6">
                  <div className="flex items-center gap-2 mb-3">
                    <CheckCircle className="w-6 h-6 text-secondary" />
                    <span className="text-lg font-semibold text-secondary">Instant Estimate Ready!</span>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Estimated Build Cost</p>
                      <p className="text-2xl font-bold text-primary">{formData.budgetRange} AED</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Build Type</p>
                      <p className="text-lg font-semibold capitalize">{formData.purpose.replace('-', ' & ')}</p>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground mt-3">
                    Final quote will include detailed component list and exact pricing
                  </p>
                </div>
              )}

              <div className="bg-muted/50 rounded-lg p-4">
                <p className="text-sm text-muted-foreground">
                  <strong>Optional:</strong> These preferences help us recommend the best components for your build. 
                  You can skip this step if you'd like our experts to choose the optimal configuration.
                </p>
              </div>
            </div>
          )}

          {/* Step 3: Contact & Finalize */}
          {currentStep === 3 && (
            <div className="space-y-6 animate-fade-in">
              <div className="space-y-2">
                <Label htmlFor="email">Email Address *</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  placeholder="Enter your email address"
                  required
                  className="bg-input border-border"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="additionalNotes">Additional Notes</Label>
                <Textarea
                  id="additionalNotes"
                  value={formData.additionalNotes}
                  onChange={(e) => handleInputChange('additionalNotes', e.target.value)}
                  placeholder="Tell us about specific games you play, any particular requirements, existing peripherals, or any other details..."
                  rows={4}
                  className="bg-input border-border resize-none"
                />
              </div>

              {/* Summary */}
              <div className="bg-card/50 border border-border rounded-lg p-4">
                <h4 className="font-semibold mb-3 text-neon">Quote Summary</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Name:</span>
                    <span>{formData.fullName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Budget:</span>
                    <span>{formData.budgetRange} AED</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Purpose:</span>
                    <span className="capitalize">{formData.purpose.replace('-', ' & ')}</span>
                  </div>
                  {(formData.preferredCpu || formData.preferredGpu) && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Preferences:</span>
                      <span>
                        {[formData.preferredCpu, formData.preferredGpu].filter(Boolean).join(', ') || 'None specified'}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Navigation Buttons */}
          <div className="flex justify-between pt-6">
            <Button 
              type="button" 
              variant="outline" 
              onClick={prevStep}
              disabled={currentStep === 1}
              className={currentStep === 1 ? 'invisible' : ''}
            >
              <ChevronLeft className="w-4 h-4 mr-2" />
              Previous
            </Button>

            {currentStep < totalSteps ? (
              <Button 
                type="button" 
                variant="gaming" 
                onClick={nextStep}
                disabled={!isStepValid(currentStep)}
              >
                Next Step
                <ChevronRight className="w-4 h-4 ml-2" />
              </Button>
            ) : (
              <Button 
                type="submit" 
                variant="gaming" 
                disabled={!isStepValid(3)}
                className="min-w-[120px]"
              >
                <Send className="w-4 h-4 mr-2" />
                Submit Quote
              </Button>
            )}
          </div>

          <p className="text-xs text-muted-foreground text-center pt-4">
            By submitting this form, you agree to receive follow-up communications from AMZ TECH regarding your quote request.
          </p>
        </form>
      </CardContent>
    </Card>
  );
};