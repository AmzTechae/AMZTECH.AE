import React, { useState, useEffect } from 'react';

const PCAssemblyAnimation: React.FC = () => {
  const [animationStep, setAnimationStep] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setAnimationStep(prev => (prev + 1) % 6);
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="w-full h-full relative flex items-center justify-center bg-gradient-to-br from-slate-900 to-slate-800">
      <div className="relative w-96 h-96">
        <svg
          viewBox="0 0 400 400"
          className="w-full h-full"
          style={{ filter: 'drop-shadow(0 0 20px rgba(99, 102, 241, 0.3))' }}
        >
          {/* Motherboard - always visible */}
          <rect
            x="50"
            y="150"
            width="300"
            height="200"
            rx="15"
            fill="#1e293b"
            stroke="#334155"
            strokeWidth="2"
            className="animate-fade-in"
          />
          
          {/* Motherboard details */}
          <rect x="80" y="180" width="240" height="140" rx="8" fill="#0f172a" opacity="0.5" />
          
          {/* CPU Socket */}
          <rect x="130" y="200" width="60" height="60" rx="5" fill="#334155" stroke="#64748b" strokeWidth="1" />
          
          {/* RAM Slots */}
          <rect x="70" y="190" width="15" height="80" rx="2" fill="#64748b" />
          <rect x="90" y="190" width="15" height="80" rx="2" fill="#64748b" />
          <rect x="300" y="190" width="15" height="80" rx="2" fill="#64748b" />
          <rect x="320" y="190" width="15" height="80" rx="2" fill="#64748b" />
          
          {/* PCIe Slots */}
          <rect x="80" y="290" width="200" height="8" rx="2" fill="#ffffff" opacity="0.8" />
          <rect x="80" y="305" width="120" height="6" rx="2" fill="#e2e8f0" opacity="0.8" />
          
          {/* CPU - Step 1 */}
          <g
            className={`transition-all duration-1000 ease-bounce ${
              animationStep >= 1 
                ? 'translate-y-0 opacity-100 scale-100' 
                : '-translate-y-32 opacity-0 scale-75'
            }`}
            transform-origin="160 230"
          >
            <rect x="135" y="205" width="50" height="50" rx="8" fill="#3b82f6" />
            <circle cx="145" cy="215" r="3" fill="#60a5fa" />
            <circle cx="175" cy="215" r="3" fill="#60a5fa" />
            <circle cx="145" cy="245" r="3" fill="#60a5fa" />
            <circle cx="175" cy="245" r="3" fill="#60a5fa" />
            <text x="160" y="235" textAnchor="middle" fill="white" fontSize="10" fontWeight="bold">CPU</text>
          </g>

          {/* RAM Stick 1 - Step 2 */}
          <g
            className={`transition-all duration-1000 ease-bounce ${
              animationStep >= 2 
                ? 'translate-x-0 opacity-100 scale-100' 
                : '-translate-x-32 opacity-0 scale-75'
            }`}
            transform-origin="77 230"
          >
            <rect x="72" y="195" width="10" height="70" rx="3" fill="#ef4444" />
            <circle cx="77" cy="205" r="1.5" fill="#fca5a5" />
            <circle cx="77" cy="220" r="1.5" fill="#fca5a5" />
            <circle cx="77" cy="235" r="1.5" fill="#fca5a5" />
            <circle cx="77" cy="250" r="1.5" fill="#fca5a5" />
          </g>

          {/* RAM Stick 2 - Step 3 */}
          <g
            className={`transition-all duration-1000 ease-bounce ${
              animationStep >= 3 
                ? 'translate-x-0 opacity-100 scale-100' 
                : 'translate-x-32 opacity-0 scale-75'
            }`}
            transform-origin="307 230"
          >
            <rect x="302" y="195" width="10" height="70" rx="3" fill="#ef4444" />
            <circle cx="307" cy="205" r="1.5" fill="#fca5a5" />
            <circle cx="307" cy="220" r="1.5" fill="#fca5a5" />
            <circle cx="307" cy="235" r="1.5" fill="#fca5a5" />
            <circle cx="307" cy="250" r="1.5" fill="#fca5a5" />
          </g>

          {/* GPU - Step 4 */}
          <g
            className={`transition-all duration-1000 ease-bounce ${
              animationStep >= 4 
                ? 'translate-y-0 opacity-100 scale-100' 
                : 'translate-y-16 opacity-0 scale-75'
            }`}
            transform-origin="180 295"
          >
            <rect x="85" y="285" width="190" height="20" rx="5" fill="#eab308" />
            <rect x="100" y="275" width="160" height="15" rx="3" fill="#fbbf24" />
            <circle cx="130" cy="282" r="4" fill="#facc15" />
            <circle cx="230" cy="282" r="4" fill="#facc15" />
            <text x="180" y="297" textAnchor="middle" fill="white" fontSize="8" fontWeight="bold">GPU</text>
          </g>

          {/* CPU Cooler - Step 5 */}
          <g
            className={`transition-all duration-1000 ease-bounce ${
              animationStep >= 5 
                ? 'translate-y-0 opacity-100 scale-100' 
                : '-translate-y-24 opacity-0 scale-75'
            }`}
            transform-origin="160 200"
          >
            <rect x="125" y="185" width="70" height="30" rx="8" fill="#6b7280" />
            <circle cx="160" cy="200" r="20" fill="#374151" stroke="#9ca3af" strokeWidth="2" />
            
            {/* Fan blades - spinning when running */}
            <g
              className={animationStep >= 5 ? 'animate-spin' : ''}
              transform-origin="160 200"
              style={{ animationDuration: '0.5s' }}
            >
              <line x1="145" y1="200" x2="175" y2="200" stroke="#9ca3af" strokeWidth="2" strokeLinecap="round" />
              <line x1="160" y1="185" x2="160" y2="215" stroke="#9ca3af" strokeWidth="2" strokeLinecap="round" />
              <line x1="148" y1="188" x2="172" y2="212" stroke="#9ca3af" strokeWidth="2" strokeLinecap="round" />
              <line x1="172" y1="188" x2="148" y2="212" stroke="#9ca3af" strokeWidth="2" strokeLinecap="round" />
            </g>
            <text x="160" y="175" textAnchor="middle" fill="white" fontSize="8" fontWeight="bold">COOLER</text>
          </g>

          {/* Assembly progress indicators */}
          <g className="opacity-80">
            {Array.from({ length: 6 }, (_, i) => (
              <circle
                key={i}
                cx={60 + i * 15}
                cy={100}
                r="4"
                fill={animationStep >= i ? '#10b981' : '#374151'}
                className="transition-colors duration-300"
              />
            ))}
          </g>

          {/* Running state effects */}
          {animationStep >= 5 && (
            <>
              {/* Power LED */}
              <circle cx="320" cy="170" r="3" fill="#10b981" className="animate-pulse" />
              
              {/* Status text */}
              <text x="200" y={animationStep >= 5 ? "380" : "400"} 
                    textAnchor="middle" 
                    fill="#10b981" 
                    fontSize="14" 
                    fontWeight="bold"
                    className="animate-fade-in">
                ✓ PC ASSEMBLED & RUNNING
              </text>
            </>
          )}
        </svg>

        {/* Step labels */}
        <div className="absolute top-4 left-1/2 transform -translate-x-1/2">
          <div className="bg-slate-800/90 backdrop-blur-sm px-4 py-2 rounded-lg border border-slate-600">
            <p className="text-slate-300 text-sm font-medium">
              {animationStep === 0 && "Motherboard Ready"}
              {animationStep === 1 && "Installing CPU..."}
              {animationStep === 2 && "Adding RAM (1/2)..."}
              {animationStep === 3 && "Adding RAM (2/2)..."}
              {animationStep === 4 && "Inserting GPU..."}
              {animationStep === 5 && "CPU Cooler Installed"}
            </p>
          </div>
        </div>

        {/* Fun floating particles when running */}
        {animationStep >= 5 && (
          <div className="absolute inset-0 pointer-events-none">
            {Array.from({ length: 8 }, (_, i) => (
              <div
                key={i}
                className="absolute w-1 h-1 bg-green-400 rounded-full animate-bounce opacity-60"
                style={{
                  left: `${20 + Math.random() * 60}%`,
                  top: `${20 + Math.random() * 60}%`,
                  animationDelay: `${i * 0.2}s`,
                  animationDuration: '2s'
                }}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default PCAssemblyAnimation;