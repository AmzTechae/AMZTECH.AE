import React from 'react';
import { MessageCircle } from 'lucide-react';

const StickyWhatsApp = () => {
  return (
    <a
      href="https://api.whatsapp.com/send?phone=971564689006&text=Hi%2C%20I%27m%20interested%20in%20a%20custom%20gaming%20PC%20build"
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-4 right-4 z-50 btn-gaming min-h-[56px] min-w-[56px] p-4 rounded-full shadow-lg animate-glow md:hidden"
      aria-label="Contact us on WhatsApp"
    >
      <MessageCircle className="w-7 h-7" />
    </a>
  );
};

export default StickyWhatsApp;