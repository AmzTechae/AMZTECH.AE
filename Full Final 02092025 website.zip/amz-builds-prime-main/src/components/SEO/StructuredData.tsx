import { useEffect } from 'react';

// Local Business Schema
export const LocalBusinessSchema = {
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "@id": "https://amztech.ae/#localbusiness",
  "name": "AMZ TECH",
  "description": "Custom Gaming PC Builds and Computer Building Services in Dubai, UAE. Expert PC builders offering 360° warranty, free delivery, and best market prices.",
  "url": "https://amztech.ae",
  "telephone": "+971-50-123-4567",
  "email": "info@amztech.ae",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "Sheikh Zayed Road",
    "addressLocality": "Dubai",
    "addressRegion": "Dubai",
    "postalCode": "00000",
    "addressCountry": "AE"
  },
  "geo": {
    "@type": "GeoCoordinates",
    "latitude": 25.2048,
    "longitude": 55.2708
  },
  "openingHoursSpecification": [
    {
      "@type": "OpeningHoursSpecification",
      "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
      "opens": "09:00",
      "closes": "18:00"
    },
    {
      "@type": "OpeningHoursSpecification",
      "dayOfWeek": "Saturday",
      "opens": "10:00",
      "closes": "16:00"
    }
  ],
  "priceRange": "$$",
  "acceptsReservations": "True",
  "currenciesAccepted": "AED",
  "paymentAccepted": ["Cash", "Credit Card", "Bank Transfer"],
  "serviceArea": [
    {
      "@type": "State",
      "name": "Dubai",
      "containedInPlace": {
        "@type": "Country", 
        "name": "United Arab Emirates"
      }
    },
    {
      "@type": "State", 
      "name": "Abu Dhabi",
      "containedInPlace": {
        "@type": "Country",
        "name": "United Arab Emirates" 
      }
    },
    {
      "@type": "State",
      "name": "Sharjah", 
      "containedInPlace": {
        "@type": "Country",
        "name": "United Arab Emirates"
      }
    },
    {
      "@type": "State",
      "name": "Ajman",
      "containedInPlace": {
        "@type": "Country", 
        "name": "United Arab Emirates"
      }
    },
    {
      "@type": "State",
      "name": "Ras Al Khaimah",
      "containedInPlace": {
        "@type": "Country",
        "name": "United Arab Emirates"
      }
    },
    {
      "@type": "State", 
      "name": "Fujairah",
      "containedInPlace": {
        "@type": "Country",
        "name": "United Arab Emirates"
      }
    },
    {
      "@type": "State",
      "name": "Umm Al Quwain", 
      "containedInPlace": {
        "@type": "Country",
        "name": "United Arab Emirates"
      }
    }
  ],
  "makesOffer": [
    {
      "@type": "Offer",
      "itemOffered": {
        "@type": "Service",
        "name": "Custom Gaming PC Build",
        "description": "Professional custom gaming PC building service with component selection, assembly, testing, and warranty"
      }
    },
    {
      "@type": "Offer",
      "itemOffered": {
        "@type": "Service",
        "name": "PC Repair and Upgrade",
        "description": "Computer repair, maintenance, and upgrade services for gaming PCs and workstations"
      }
    }
  ]
};

// Organization Schema
export const OrganizationSchema = {
  "@context": "https://schema.org",
  "@type": "Organization",
  "@id": "https://amztech.ae/#organization",
  "name": "AMZ TECH",
  "url": "https://amztech.ae",
  "logo": "https://amztech.ae/logo.png",
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "+971-50-123-4567",
    "contactType": "customer service",
    "availableLanguage": ["English", "Arabic"],
    "areaServed": "AE"
  },
  "sameAs": [
    "https://www.facebook.com/amztech.uae",
    "https://www.instagram.com/amztech.uae",
    "https://twitter.com/amztech_uae"
  ]
};

// Website Schema
export const WebsiteSchema = {
  "@context": "https://schema.org",
  "@type": "WebSite",
  "@id": "https://amztech.ae/#website",
  "name": "AMZ TECH - Custom Gaming PC Builds Dubai UAE",
  "url": "https://amztech.ae",
  "potentialAction": {
    "@type": "SearchAction",
    "target": {
      "@type": "EntryPoint",
      "urlTemplate": "https://amztech.ae/search?q={search_term_string}"
    },
    "query-input": "required name=search_term_string"
  }
};

// Service Schema
export const ServiceSchema = {
  "@context": "https://schema.org",
  "@type": "Service",
  "@id": "https://amztech.ae/#service",
  "name": "Custom Gaming PC Building Service",
  "description": "Professional custom gaming PC building service in Dubai, UAE. We select the best components, assemble, test, and deliver your dream gaming PC with full warranty.",
  "provider": {
    "@id": "https://amztech.ae/#organization"
  },
  "areaServed": {
    "@type": "Country", 
    "name": "United Arab Emirates"
  },
  "hasOfferCatalog": {
    "@type": "OfferCatalog",
    "name": "Gaming PC Build Packages",
    "itemListElement": [
      {
        "@type": "Offer",
        "itemOffered": {
          "@type": "Product",
          "name": "Budget Gaming PC Build",
          "description": "Entry-level gaming PC build perfect for 1080p gaming"
        },
        "priceRange": "2000-4000 AED"
      },
      {
        "@type": "Offer",
        "itemOffered": {
          "@type": "Product",
          "name": "Mid-Range Gaming PC Build",
          "description": "Balanced gaming PC build for 1440p gaming and streaming"
        },
        "priceRange": "4000-8000 AED"
      },
      {
        "@type": "Offer",
        "itemOffered": {
          "@type": "Product",
          "name": "High-End Gaming PC Build",
          "description": "Premium gaming PC build for 4K gaming and professional work"
        },
        "priceRange": "8000-15000 AED"
      }
    ]
  }
};

interface StructuredDataProps {
  schema: object;
  id?: string;
}

const StructuredData = ({ schema, id = "structured-data" }: StructuredDataProps) => {
  useEffect(() => {
    let script = document.querySelector(`#${id}`) as HTMLScriptElement;
    
    if (!script) {
      script = document.createElement('script');
      script.id = id;
      script.type = 'application/ld+json';
      document.head.appendChild(script);
    }
    
    script.textContent = JSON.stringify(schema);

    return () => {
      if (script && script.parentNode) {
        script.parentNode.removeChild(script);
      }
    };
  }, [schema, id]);

  return null;
};

export default StructuredData;