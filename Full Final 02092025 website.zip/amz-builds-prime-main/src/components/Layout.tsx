import React from 'react';
import Navigation from './Navigation';
import Footer from './Footer';
import StickyWhatsApp from './StickyWhatsApp';
import ScrollManager from './ScrollManager';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout = ({ children }: LayoutProps) => {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <ScrollManager />
      <Navigation />
      <main className="relative">
        {children}
      </main>
      <Footer />
      <StickyWhatsApp />
    </div>
  );
};

export default Layout;