import React, { useState } from 'react';
import { MessageCircle, Mail, Phone, MapPin, Send, Copy, ExternalLink, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { ProgressiveQuoteForm } from '@/components/ui/progress-form';

const Contact = () => {
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [emailContent, setEmailContent] = useState({ subject: '', body: '' });
  const [copied, setCopied] = useState(false);
  
  // Quick contact email modal states
  const [showQuickEmailModal, setShowQuickEmailModal] = useState(false);
  const [quickEmailContent, setQuickEmailContent] = useState({ subject: '', body: '' });
  const [quickCopied, setQuickCopied] = useState(false);

  // Check if device is mobile
  const isMobile = () => {
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) || window.innerWidth < 768;
  };

  const handleProgressiveFormSubmit = (formData: any) => {
    // Create formatted email content
    const emailSubject = `Custom PC Build Quote Request - ${formData.fullName}`;
    const emailBody = `Dear AMZ TECH Team,

I would like to request a quote for a custom PC build with the following specifications:

CUSTOMER INFORMATION:
- Name: ${formData.fullName}
- Email: ${formData.email}
- Phone/WhatsApp: ${formData.phone}

BUILD REQUIREMENTS:
- Budget Range: ${formData.budgetRange}
- Primary Purpose: ${formData.purpose}
- Preferred CPU Brand: ${formData.preferredCpu || 'No preference specified'}
- Preferred GPU Brand: ${formData.preferredGpu || 'No preference specified'}

ADDITIONAL NOTES:
${formData.additionalNotes || 'No additional notes provided'}

Please provide me with a detailed quote and recommendations.

Best regards,
${formData.fullName}`;

    // On mobile, directly open email client. On desktop, show modal with options
    if (isMobile()) {
      const recipientEmail = 'info@amztech.ae';
      window.location.href = `mailto:${recipientEmail}?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(emailBody)}`;
    } else {
      // Desktop: Store email content and show modal with options
      setEmailContent({ subject: emailSubject, body: emailBody });
      setShowEmailModal(true);
    }
  };

  const handleEmailOption = (option: string) => {
    const { subject, body } = emailContent;
    const recipientEmail = 'info@amztech.ae';

    switch (option) {
      case 'mailto':
        window.open(`mailto:${recipientEmail}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`);
        break;
      case 'gmail':
        window.open(`https://mail.google.com/mail/?view=cm&to=${recipientEmail}&su=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`, '_blank');
        break;
      case 'outlook':
        window.open(`https://outlook.live.com/mail/0/deeplink/compose?to=${recipientEmail}&subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`, '_blank');
        break;
      case 'copy':
        const emailText = `To: ${recipientEmail}\nSubject: ${subject}\n\n${body}`;
        navigator.clipboard.writeText(emailText).then(() => {
          setCopied(true);
          setTimeout(() => setCopied(false), 2000);
        });
        break;
    }

    setShowEmailModal(false);
  };

  // Quick contact email handler
  const handleQuickEmail = () => {
    // Create formatted email content for general inquiry
    const emailSubject = 'PC Build Consultation Inquiry';
    const emailBody = `Dear AMZ TECH Team,

I am interested in learning more about your custom PC building services and would like to discuss my requirements.

Please contact me to discuss:
- Available PC build options
- Pricing and packages
- Consultation scheduling
- Any current promotions

I look forward to hearing from you soon.

Best regards`;

    // On mobile, directly open email client. On desktop, show modal with options
    if (isMobile()) {
      const recipientEmail = 'info@amztech.ae';
      window.location.href = `mailto:${recipientEmail}?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(emailBody)}`;
    } else {
      // Desktop: Store email content and show modal with options
      setQuickEmailContent({ subject: emailSubject, body: emailBody });
      setShowQuickEmailModal(true);
    }
  };

  const handleQuickEmailOption = (option: string) => {
    const { subject, body } = quickEmailContent;
    const recipientEmail = 'info@amztech.ae';

    switch (option) {
      case 'mailto':
        window.open(`mailto:${recipientEmail}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`);
        break;
      case 'gmail':
        window.open(`https://mail.google.com/mail/?view=cm&to=${recipientEmail}&su=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`, '_blank');
        break;
      case 'outlook':
        window.open(`https://outlook.live.com/mail/0/deeplink/compose?to=${recipientEmail}&subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`, '_blank');
        break;
    }

    setShowQuickEmailModal(false);
  };


  return (
    <div className="min-h-screen pt-16">
      {/* Hero Section */}
      <section className="mobile-section hero-bg">
        <div className="container mx-auto mobile-container">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="section-header mb-6 lg:mb-8">Get Your Custom PC Quote</h1>
            <p className="mobile-text-lg sm:text-xl text-muted-foreground mb-6 lg:mb-8">
              Ready to build your dream gaming PC? Fill out our detailed quote form and 
              our experts will create a custom configuration that perfectly matches your 
              needs and budget in Dubai.
            </p>
          </div>
        </div>
      </section>

      <div className="container mx-auto mobile-container py-12 lg:py-16">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 lg:gap-12">
          {/* Contact Information */}
          <div className="space-y-8">
            <Card className="gaming-card">
              <CardHeader>
                <CardTitle className="text-neon">Contact Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center space-x-4">
                  <MessageCircle className="w-6 h-6 text-primary" />
                  <div>
                    <p className="font-semibold">WhatsApp</p>
                    <a 
                      href="https://api.whatsapp.com/send?phone=971564689006" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-primary hover:text-primary/80 transition-colors"
                    >
                      +971 56 468 9006
                    </a>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4">
                  <Mail className="w-6 h-6 text-primary" />
                  <div>
                    <p className="font-semibold">Email</p>
                    <a 
                      href="mailto:info@amztech.ae"
                      className="text-primary hover:text-primary/80 transition-colors"
                    >
                      info@amztech.ae
                    </a>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4">
                  <Phone className="w-6 h-6 text-primary" />
                  <div>
                    <p className="font-semibold">Phone</p>
                    <span className="text-muted-foreground">+971 56 468 9006</span>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4">
                  <MapPin className="w-6 h-6 text-primary" />
                  <div>
                    <p className="font-semibold">Location</p>
                    <span className="text-muted-foreground">Dubai, UAE</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="gaming-card">
              <CardHeader>
                <CardTitle className="text-neon">Quick Contact</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button variant="gaming" className="w-full" asChild>
                  <a 
                    href="https://api.whatsapp.com/send?phone=971564689006&text=Hi%2C%20I%27m%20interested%20in%20a%20custom%20gaming%20PC%20build"
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center justify-center"
                  >
                    <MessageCircle className="w-5 h-5 mr-2" />
                    WhatsApp Chat
                  </a>
                </Button>
                <Button 
                  variant="gaming-outline" 
                  className="w-full" 
                  onClick={handleQuickEmail}
                >
                  <Mail className="w-5 h-5 mr-2" />
                  Send Email
                </Button>
              </CardContent>
            </Card>

          </div>

          {/* Progressive Quote Request Form */}
          <div id="quote-form" className="lg:col-span-2 scroll-mt-24">
            <ProgressiveQuoteForm onSubmit={handleProgressiveFormSubmit} />
          </div>
        </div>
      </div>

      {/* FAQ Section */}
      <section className="mobile-section bg-gaming-grid">
        <div className="container mx-auto mobile-container">
          <div className="max-w-4xl mx-auto">
            <h2 className="section-header text-center mb-8 lg:mb-12">Frequently Asked Questions</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
              <Card className="gaming-card">
                <CardContent className="pt-6">
                  <h3 className="font-bold text-lg mb-3 text-neon">How long does a custom build take?</h3>
                  <p className="text-muted-foreground">
                    Most custom builds are completed within 2-3 business days. Complex builds 
                    with custom cooling may take up to 5 days. Rush orders available for urgent needs.
                  </p>
                </CardContent>
              </Card>

              <Card className="gaming-card">
                <CardContent className="pt-6">
                  <h3 className="font-bold text-lg mb-3 text-neon">Do you provide warranty?</h3>
                  <p className="text-muted-foreground">
                    Yes! We provide comprehensive warranty coverage on all components plus our 
                    build service. Individual components carry manufacturer warranty, and we 
                    provide additional service warranty.
                  </p>
                </CardContent>
              </Card>

              <Card className="gaming-card">
                <CardContent className="pt-6">
                  <h3 className="font-bold text-lg mb-3 text-neon">Can I upgrade my existing PC?</h3>
                  <p className="text-muted-foreground">
                    Absolutely! We offer PC upgrade services including graphics cards, RAM, 
                    storage, and cooling systems. Bring your PC for a free consultation and quote.
                  </p>
                </CardContent>
              </Card>

              <Card className="gaming-card">
                <CardContent className="pt-6">
                  <h3 className="font-bold text-lg mb-3 text-neon">Do you offer financing options?</h3>
                  <p className="text-muted-foreground">
                    Yes, we partner with Tabby for flexible payment options. Buy now and pay 
                    in 4 interest-free installments, making your dream PC more affordable.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>
      
      {/* Email Options Modal */}
      <AlertDialog open={showEmailModal} onOpenChange={setShowEmailModal}>
        <AlertDialogContent className="gaming-card max-w-md">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-neon">Choose Email Option</AlertDialogTitle>
            <AlertDialogDescription>
              How would you like to send your quote request to AMZ TECH?
            </AlertDialogDescription>
          </AlertDialogHeader>
          
          <div className="space-y-3">
            <Button 
              variant="gaming" 
              className="w-full justify-start" 
              onClick={() => handleEmailOption('mailto')}
            >
              <Mail className="w-4 h-4 mr-2" />
              Open Email Client
            </Button>
            
            <Button 
              variant="gaming-outline" 
              className="w-full justify-start" 
              onClick={() => handleEmailOption('gmail')}
            >
              <ExternalLink className="w-4 h-4 mr-2" />
              Open Gmail
            </Button>
            
            <Button 
              variant="gaming-outline" 
              className="w-full justify-start" 
              onClick={() => handleEmailOption('outlook')}
            >
              <ExternalLink className="w-4 h-4 mr-2" />
              Open Outlook
            </Button>
            
            <Button 
              variant="secondary" 
              className="w-full justify-start" 
              onClick={() => handleEmailOption('copy')}
            >
              {copied ? (
                <>
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Copied to Clipboard!
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 mr-2" />
                  Copy Email Content
                </>
              )}
            </Button>
          </div>
          
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Quick Contact Email Options Modal */}
      <AlertDialog open={showQuickEmailModal} onOpenChange={setShowQuickEmailModal}>
        <AlertDialogContent className="gaming-card max-w-md">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-neon">Send Email</AlertDialogTitle>
            <AlertDialogDescription>
              How would you like to send your inquiry to AMZ TECH?
            </AlertDialogDescription>
          </AlertDialogHeader>
          
          <div className="space-y-3">
            <Button 
              variant="gaming" 
              className="w-full justify-start" 
              onClick={() => handleQuickEmailOption('mailto')}
            >
              <Mail className="w-4 h-4 mr-2" />
              Open Email Client
            </Button>
            
            <Button 
              variant="gaming-outline" 
              className="w-full justify-start" 
              onClick={() => handleQuickEmailOption('gmail')}
            >
              <ExternalLink className="w-4 h-4 mr-2" />
              Open Gmail
            </Button>
            
            <Button 
              variant="gaming-outline" 
              className="w-full justify-start" 
              onClick={() => handleQuickEmailOption('outlook')}
            >
              <ExternalLink className="w-4 h-4 mr-2" />
              Open Outlook
            </Button>
          </div>
          
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default Contact;