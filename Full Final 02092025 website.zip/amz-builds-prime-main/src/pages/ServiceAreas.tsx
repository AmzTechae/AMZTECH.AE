import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { MapPin, Phone, Clock, Star, Zap, Shield, Truck, Package, HelpCircle } from 'lucide-react';
import { Link } from 'react-router-dom';
import SEOHead from '@/components/SEO/SEOHead';
import StructuredData, { LocalBusinessSchema, ServiceSchema } from '@/components/SEO/StructuredData';
import Breadcrumbs from '@/components/SEO/Breadcrumbs';
import { uaeServiceAreas, metaDescriptions, faqData } from '@/data/seoData';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

const ServiceAreas = () => {
  const scrollToFAQ = () => {
    const faqSection = document.getElementById('faq-section');
    if (faqSection) {
      faqSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const structuredData = {
    ...LocalBusinessSchema,
    "name": "AMZ TECH - Gaming PC Builds UAE",
    "description": "Custom gaming PC builds across UAE. Professional PC building services for all seven emirates with nationwide delivery and expert assembly.",
    "areaServed": {
      "@type": "Country",
      "name": "United Arab Emirates"
    },
    "hasMap": "https://maps.google.com/?q=United+Arab+Emirates"
  };

  const services = [
    {
      title: "Dubai & Northern Emirates",
      description: "Next-day delivery for Dubai, Sharjah, and Ajman if ordered before 12pm. Premium service for UAE's most populated regions.",
      areas: ["Dubai", "Sharjah", "Ajman"],
      delivery: "Next Day",
      icon: Zap,
      highlight: true
    },
    {
      title: "Abu Dhabi Capital Region", 
      description: "Professional service for UAE's capital including Abu Dhabi city, Al Ain, and surrounding areas.",
      areas: ["Abu Dhabi City", "Al Ain", "Ruwais", "Madinat Zayed"],
      delivery: "2-3 Days",
      icon: Star
    },
    {
      title: "Eastern & Northern Emirates",
      description: "Complete coverage for RAK, Fujairah, and UAQ with expert PC building and reliable delivery service.",
      areas: ["Ras Al Khaimah", "Fujairah", "Umm Al Quwain", "Khor Fakkan"],
      delivery: "2-3 Days", 
      icon: Shield
    }
  ];

  const whyChooseUs = [
    {
      title: "Nationwide Coverage",
      description: "Only PC builder serving all 7 UAE emirates with consistent quality and service standards",
      icon: MapPin
    },
    {
      title: "Local Expertise",
      description: "Deep understanding of each emirate's market, logistics, and customer preferences",
      icon: Star
    },
    {
      title: "Flexible Delivery",
      description: "Next-day delivery in Dubai/Sharjah/Ajman (before 12pm), 2-3 days nationwide, with 24h setup time",
      icon: Truck
    },
    {
      title: "Best Prices",
      description: "Competitive pricing across all emirates with transparent costs and no hidden fees",
      icon: Package
    }
  ];

  return (
    <>
      <SEOHead
        title="Gaming PC Service Areas UAE - All Emirates | AMZ TECH Nationwide Delivery"
        description={metaDescriptions.serviceAreas}
        keywords="Gaming PC UAE all emirates, Custom PC Dubai Abu Dhabi Sharjah, PC Builder nationwide UAE, Gaming PC delivery all emirates"
        type="website"
        canonical="https://amztech.ae/service-areas"
        structuredData={structuredData}
      />
      
      <StructuredData schema={ServiceSchema} id="service-schema" />
      
      <div className="min-h-screen bg-background">
        {/* Hero Section */}
        <section className="hero-bg mobile-section">
          <div className="container mx-auto mobile-container">
            <Breadcrumbs />
            
            <div className="text-center mb-12">
              <div className="flex items-center justify-center mb-4">
                <MapPin className="h-8 w-8 text-primary mr-3" />
                <h1 className="section-header">Gaming PC Service Areas - All UAE</h1>
              </div>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-8">
                Professional custom gaming PC builds serving all seven UAE emirates. From Dubai to Fujairah, 
                Abu Dhabi to RAK - we deliver excellence nationwide with consistent quality and competitive pricing.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
                <Button asChild className="btn-gaming">
                  <Link to="/contact">Get Free Quote</Link>
                </Button>
                <Button variant="outline" asChild className="btn-outline-gaming">
                  <Link to="/sample-builds">View Sample Builds</Link>
                </Button>
              </div>

              {/* Delivery Promise */}
              <div className="bg-card border border-border rounded-lg p-6 max-w-2xl mx-auto mb-6">
                <h3 className="text-lg font-semibold text-foreground mb-4">Our Delivery Promise</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                    <span className="text-muted-foreground">24-hour setup after payment</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                    <span className="text-muted-foreground">Next-day delivery (Dubai, Sharjah, Ajman)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                    <span className="text-muted-foreground">Order before 12pm for next-day</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                    <span className="text-muted-foreground">2-3 days delivery (other emirates)</span>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground mt-4 italic">
                  *Delivery times apply to basic builds. Any changes will be communicated before confirmation.
                </p>
              </div>
              
              <div className="flex items-center justify-center mt-6 space-x-6 text-sm text-muted-foreground">
                <div className="flex items-center">
                  <MapPin className="h-4 w-4 mr-2 text-primary" />
                  All 7 Emirates
                </div>
                <div className="flex items-center">
                  <Truck className="h-4 w-4 mr-2 text-primary" />
                  Nationwide Delivery
                </div>
                <div className="flex items-center">
                  <Shield className="h-4 w-4 mr-2 text-primary" />
                  360° Warranty
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Service Regions */}
        <section className="mobile-section">
          <div className="container mx-auto mobile-container">
            <div className="text-center mb-12">
              <h2 className="section-header">Service Regions & Delivery</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Comprehensive coverage across UAE with optimized delivery routes for each region
              </p>
            </div>
            
            <div className="grid md:grid-cols-3 gap-8 mb-12">
              {services.map((service, index) => {
                const Icon = service.icon;
                return (
                  <Card key={index} className={`gaming-card ${service.highlight ? 'glow-card border-primary/50' : ''}`}>
                    <CardHeader>
                      <Icon className="h-12 w-12 text-primary mb-4" />
                      <CardTitle className="flex items-center justify-between">
                        {service.title}
                        <span className="text-sm bg-primary/10 text-primary px-2 py-1 rounded">
                          {service.delivery}
                        </span>
                      </CardTitle>
                      <CardDescription className="text-base">
                        {service.description}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <p className="font-semibold text-sm">Coverage Areas:</p>
                        <div className="grid grid-cols-1 gap-1">
                          {service.areas.map((area, areaIndex) => (
                            <div key={areaIndex} className="flex items-center text-sm text-muted-foreground">
                              <div className="h-1.5 w-1.5 bg-primary rounded-full mr-2" />
                              {area}
                            </div>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        </section>

        {/* Detailed Emirates Coverage */}
        <section className="mobile-section bg-muted/30">
          <div className="container mx-auto mobile-container">
            <div className="text-center mb-12">
              <h2 className="section-header">Emirates Coverage Details</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Specific areas we serve in each emirate with delivery timeframes
              </p>
            </div>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {uaeServiceAreas.map((emirate, index) => (
                <Card key={index} className="gaming-card">
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between text-lg">
                      {emirate.name}
                      <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded">
                        {emirate.deliveryTime}
                      </span>
                    </CardTitle>
                    <CardDescription>
                      {emirate.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div>
                        <p className="font-semibold text-sm mb-2">Major Areas:</p>
                        <div className="grid grid-cols-1 gap-1">
                          {emirate.areas.slice(0, 4).map((area, areaIndex) => (
                            <div key={areaIndex} className="flex items-center text-sm text-muted-foreground">
                              <div className="h-1 w-1 bg-primary rounded-full mr-2" />
                              {area}
                            </div>
                          ))}
                          {emirate.areas.length > 4 && (
                            <div className="text-sm text-muted-foreground ml-3">
                              +{emirate.areas.length - 4} more areas
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Why Choose Us */}
        <section className="mobile-section">
          <div className="container mx-auto mobile-container">
            <div className="text-center mb-12">
              <h2 className="section-header">Why Choose AMZ TECH Nationwide</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                The only gaming PC builder with true UAE-wide coverage and consistent service quality
              </p>
            </div>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {whyChooseUs.map((feature, index) => {
                const Icon = feature.icon;
                return (
                  <Card key={index} className="gaming-card text-center">
                    <CardContent className="pt-6">
                      <Icon className="h-12 w-12 text-primary mx-auto mb-4" />
                      <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                      <p className="text-muted-foreground text-sm">{feature.description}</p>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        </section>

        {/* Contact Info */}
        <section className="mobile-section bg-muted/30">
          <div className="container mx-auto mobile-container">
            <div className="grid md:grid-cols-2 gap-8">
              <Card className="gaming-card">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Phone className="h-5 w-5 mr-2 text-primary" />
                    Contact & Support
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <p className="font-semibold">WhatsApp & Phone</p>
                      <p className="text-primary">+971 56 468 9006</p>
                    </div>
                    <div>
                      <p className="font-semibold">Email Support</p>
                      <p className="text-muted-foreground">info@amztech.ae</p>
                    </div>
                    <div>
                      <p className="font-semibold">Service Hours</p>
                      <p className="text-muted-foreground">Mon-Fri: 9AM-6PM</p>
                      <p className="text-muted-foreground">Saturday: 10AM-4PM</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="gaming-card">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Truck className="h-5 w-5 mr-2 text-primary" />
                    Delivery Information
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <p className="font-semibold">Next Day Delivery</p>
                      <p className="text-muted-foreground">Dubai, Sharjah, Ajman (if ordered before 12pm)</p>
                    </div>
                    <div>
                      <p className="font-semibold">2-3 Days Delivery</p>
                      <p className="text-muted-foreground">Abu Dhabi, RAK, Fujairah, UAQ</p>
                    </div>
                    <div>
                      <p className="font-semibold">Setup Time</p>
                      <p className="text-muted-foreground">24 hours after payment (all emirates)</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section id="faq-section" className="mobile-section">
          <div className="container mx-auto mobile-container">
            <div className="text-center mb-12">
              <h2 className="section-header">Frequently Asked Questions</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Common questions about our UAE-wide gaming PC building services
              </p>
            </div>
            
            <div className="max-w-4xl mx-auto">
              <Accordion type="single" collapsible className="space-y-4">
                {faqData.map((faq, index) => (
                  <AccordionItem key={index} value={`item-${index}`} className="gaming-card shadow-lg">
                    <AccordionTrigger className="text-left">
                      <span className="font-semibold text-foreground">{faq.question}</span>
                    </AccordionTrigger>
                    <AccordionContent>
                      <p className="text-muted-foreground leading-relaxed">{faq.answer}</p>
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>
            
            <div className="text-center mt-8">
              <p className="text-muted-foreground mb-4">
                Have more questions? We're here to help!
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button variant="outline" asChild>
                  <Link to="/contact">Ask a Question</Link>
                </Button>
                <Button variant="outline" asChild>
                  <a href="https://wa.me/971564689006">WhatsApp Support</a>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="mobile-section bg-primary/5">
          <div className="container mx-auto mobile-container text-center">
            <h2 className="section-header mb-6">Ready to Build Your Gaming PC Anywhere in UAE?</h2>
            <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto">
              From Dubai's skyscrapers to Fujairah's mountains, from Abu Dhabi's capital to RAK's beaches - 
              we bring professional gaming PC builds to your doorstep. Get your free quote today!
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
              <Button asChild size="lg" className="btn-gaming">
                <Link to="/contact">Get Free Quote Now</Link>
              </Button>
              <Button variant="outline" size="lg" asChild className="btn-outline-gaming">
                <a href="https://wa.me/971564689006">WhatsApp Us</a>
              </Button>
            </div>
            
            <div className="flex items-center justify-center text-sm text-muted-foreground">
              <Star className="h-4 w-4 mr-1 text-yellow-500 fill-current" />
              <Star className="h-4 w-4 mr-1 text-yellow-500 fill-current" />
              <Star className="h-4 w-4 mr-1 text-yellow-500 fill-current" />
              <Star className="h-4 w-4 mr-1 text-yellow-500 fill-current" />
              <Star className="h-4 w-4 mr-2 text-yellow-500 fill-current" />
              Trusted by customers across all UAE Emirates
            </div>
          </div>
        </section>

        {/* FAQ Quick Link Button */}
        <div className="fixed bottom-6 left-6 z-50">
          <Button
            onClick={scrollToFAQ}
            size="lg"
            className="rounded-full shadow-lg hover:shadow-xl transition-all duration-300 bg-primary hover:bg-primary/90"
            aria-label="Jump to FAQ section"
          >
            <HelpCircle className="w-6 h-6 mr-2" />
            FAQ
          </Button>
        </div>
      </div>
    </>
  );
};

export default ServiceAreas;