import React from 'react';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import SEOHead from '@/components/SEO/SEOHead';

const FAQ = () => {
  const faqData = [
    {
      question: "How long does it take to build a custom gaming PC?",
      answer: "Typically, we complete custom PC builds within 3-5 business days. This includes assembly, testing, and quality assurance. For complex water-cooled systems, it may take 5-7 days."
    },
    {
      question: "Do you provide warranty on custom PC builds?",
      answer: "Yes, we provide a comprehensive 2-year warranty on our custom builds, covering both parts and labor. Individual components also come with their manufacturer warranties."
    },
    {
      question: "Can I upgrade my existing PC instead of buying a new one?",
      answer: "Absolutely! We offer upgrade services for existing systems. We can assess your current setup and recommend the most cost-effective upgrades to improve performance."
    },
    {
      question: "Do you offer financing options?",
      answer: "Yes, we offer flexible payment plans and financing options. Contact us to discuss payment arrangements that work for your budget."
    },
    {
      question: "What areas in Dubai do you serve?",
      answer: "We provide services across all areas of Dubai including Downtown, Marina, JLT, Business Bay, Deira, and surrounding emirates. We offer both pickup and delivery services."
    },
    {
      question: "Can you help me choose the right components?",
      answer: "Definitely! Our experts will work with you to select components based on your budget, performance needs, and intended use case. We provide detailed consultations before any purchase."
    }
  ];

  return (
    <>
      <SEOHead 
        title="Frequently Asked Questions - Gaming PC Dubai"
        description="Get answers to common questions about custom gaming PC builds, warranties, services, and more in Dubai, UAE."
      />
      
      <div className="min-h-screen pt-16">
        {/* Hero Section */}
        <section className="py-20 bg-gaming-grid">
          <div className="container mx-auto px-4 text-center">
            <h1 className="section-header mb-6">Frequently Asked Questions</h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Find answers to the most common questions about our gaming PC builds and services
            </p>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-20">
          <div className="container mx-auto px-4 max-w-3xl">
            <Accordion type="single" collapsible className="w-full">
              {faqData.map((faq, index) => (
                <AccordionItem key={index} value={`item-${index}`}>
                  <AccordionTrigger className="text-left">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent>
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </section>
      </div>
    </>
  );
};

export default FAQ;