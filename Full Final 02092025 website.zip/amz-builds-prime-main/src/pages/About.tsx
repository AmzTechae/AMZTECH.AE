import React from 'react';
import { Link } from 'react-router-dom';
import { Users, Award, Clock, Shield, Wrench, Heart, HelpCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

// Import images
import workspaceImage from '@/assets/pc-building-workspace.jpg';

const About = () => {
  const values = [
    {
      icon: <Heart className="w-8 h-8 text-primary" />,
      title: "Passion for Gaming",
      description: "We're gamers ourselves, building PCs with the same care we'd want for our own setups"
    },
    {
      icon: <Award className="w-8 h-8 text-primary" />,
      title: "Quality First",
      description: "Only premium components and meticulous attention to detail in every build"
    },
    {
      icon: <Users className="w-8 h-8 text-primary" />,
      title: "Customer Focused",
      description: "Your satisfaction is our priority - from consultation to after-sales support"
    },
    {
      icon: <Clock className="w-8 h-8 text-primary" />,
      title: "Fast Delivery",
      description: "Quick turnaround times without compromising on build quality"
    }
  ];

  const stats = [
    { number: "500+", label: "Custom PCs Built" },
    { number: "2+", label: "Years Experience in Field & Quality Professional" },
    { number: "24/7", label: "Technical Support" },
    { number: "100%", label: "Customer Satisfaction" }
  ];

  return (
    <div className="min-h-screen pt-16">
      {/* Hero Section */}
      <section className="py-20 hero-bg">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="section-header mb-8">About AMZ TECH</h1>
            <p className="text-xl text-muted-foreground mb-8">
              Dubai's premier custom gaming PC builder, dedicated to creating high-performance 
              systems that exceed expectations. We combine technical expertise with genuine 
              passion for gaming to deliver the ultimate PC building experience.
            </p>
            <Button variant="gaming" size="lg" asChild>
              <Link to="/contact">Start Your Build</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Our Story Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold mb-6 text-neon">Our Story</h2>
              <div className="space-y-4 text-muted-foreground">
                <p>
                  AMZ TECH was founded by AMZ Global Trading in 2025 with a simple 
                  mission: to build the best custom gaming PCs in the UAE. What began as a passion 
                  project has grown into Dubai's trusted name for custom PC builds.
                </p>
                <p>
                  We understand that every gamer, content creator, and professional has unique needs. 
                  That's why we don't believe in one-size-fits-all solutions. Every PC we build is 
                  carefully crafted to match your specific requirements, budget, and performance goals.
                </p>
                <p>
                  From budget-friendly gaming rigs to high-end workstations, we've built hundreds of 
                  systems for satisfied customers across Dubai and the UAE. Our commitment to quality, 
                  competitive pricing, and exceptional customer service has made us the go-to choice 
                  for custom PC builds in the region.
                </p>
              </div>
            </div>
            <div className="relative">
              <img 
                src={workspaceImage}
                alt="AMZ TECH PC Building Workspace"
                className="rounded-xl shadow-2xl w-full h-auto"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Our Values Section */}
      <section className="py-20 bg-gaming-grid">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="section-header">Our Values</h2>
            <p className="text-xl text-muted-foreground mt-4">
              What drives us to build the best gaming PCs in Dubai
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <Card key={index} className="gaming-card text-center">
                <CardContent className="pt-6">
                  <div className="flex justify-center mb-4">
                    {value.icon}
                  </div>
                  <h3 className="text-lg font-semibold mb-3">{value.title}</h3>
                  <p className="text-sm text-muted-foreground">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl lg:text-5xl font-bold text-neon mb-2">
                  {stat.number}
                </div>
                <div className="text-muted-foreground">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose AMZ TECH Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="section-header text-center mb-12">Why Choose AMZ TECH?</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <Shield className="w-6 h-6 text-primary mt-1" />
                  <div>
                    <h3 className="font-semibold mb-2">360° Warranty Coverage</h3>
                    <p className="text-muted-foreground">Comprehensive warranty on all components and our build service for complete peace of mind.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <Wrench className="w-6 h-6 text-primary mt-1" />
                  <div>
                    <h3 className="font-semibold mb-2">Expert Technical Service</h3>
                    <p className="text-muted-foreground">Professional assembly, cable management, and optimization for maximum performance.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <Users className="w-6 h-6 text-primary mt-1" />
                  <div>
                    <h3 className="font-semibold mb-2">Personalized Consultation</h3>
                    <p className="text-muted-foreground">One-on-one consultation to understand your needs and recommend the perfect configuration.</p>
                  </div>
                </div>
              </div>
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <Clock className="w-6 h-6 text-primary mt-1" />
                  <div>
                    <h3 className="font-semibold mb-2">Free Delivery</h3>
                    <p className="text-muted-foreground">Complimentary delivery service throughout Dubai for all PC builds and configurations.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <Award className="w-6 h-6 text-primary mt-1" />
                  <div>
                    <h3 className="font-semibold mb-2">Premium Components</h3>
                    <p className="text-muted-foreground">Only authentic, high-quality components from trusted brands with full manufacturer warranty.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <Heart className="w-6 h-6 text-primary mt-1" />
                  <div>
                    <h3 className="font-semibold mb-2">Ongoing Support</h3>
                    <p className="text-muted-foreground">24/7 technical support and lifetime consultation on upgrades and optimization.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gaming-grid">
        <div className="container mx-auto px-4 text-center">
          <h2 className="section-header mb-8">Ready to Build Your Dream PC?</h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Join hundreds of satisfied customers who chose AMZ TECH for their custom gaming PCs. 
            Get your personalized quote today.
          </p>
          <Button variant="gaming" size="lg" asChild>
            <Link to="/contact">Get Custom Quote</Link>
          </Button>
        </div>
      </section>

      {/* FAQ Quick Link Button */}
      <div className="fixed bottom-6 left-6 z-50">
        <Button
          asChild
          size="lg"
          className="rounded-full shadow-lg hover:shadow-xl transition-all duration-300 bg-primary hover:bg-primary/90"
          aria-label="Go to FAQ section"
        >
          <Link to="/service-areas#faq-section">
            <HelpCircle className="w-6 h-6 mr-2" />
            FAQ
          </Link>
        </Button>
      </div>
    </div>
  );
};

export default About;