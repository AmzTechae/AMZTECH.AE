import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Shield, 
  Truck, 
  CreditCard, 
  Headphones, 
  DollarSign, 
  Cpu,
  Star,
  Quote,
  MessageCircle,
  Mail,
  Zap,
  Target,
  Award
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import PCAssemblyAnimation from '@/components/PCAssemblyAnimation';
import SEOHead from '@/components/SEO/SEOHead';
import StructuredData, { LocalBusinessSchema, OrganizationSchema, WebsiteSchema, ServiceSchema } from '@/components/SEO/StructuredData';
import { trackQuoteRequest, trackSampleBuildView } from '@/components/Analytics/GoogleAnalytics';

const Home = () => {
  const handleQuoteRequest = () => {
    trackQuoteRequest('general', 'home_page');
  };

  const handleSampleBuildClick = (buildName: string, price: string) => {
    trackSampleBuildView(buildName, price);
  };
  const features = [
    {
      icon: <Cpu className="w-12 h-12 text-primary" />,
      title: "Custom Built",
      description: "Every PC is built from scratch based on your specific requirements and budget",
      price: "Starting from 1800 AED",
      highlight: false
    },
    {
      icon: <Shield className="w-12 h-12 text-primary" />,
      title: "360° Warranty", 
      description: "Comprehensive warranty coverage on all components and our professional build service",
      price: "1 Year Free + Extension Available",
      highlight: false
    },
    {
      icon: <Award className="w-12 h-12 text-secondary" />,
      title: "Price Match Guarantee",
      description: "Found a lower price elsewhere? We'll match it and try to beat it - guaranteed competitive pricing",
      price: "Best Price Promise",
      highlight: true
    },
    {
      icon: <CreditCard className="w-12 h-12 text-primary" />,
      title: "Tabby Payment",
      description: "Flexible payment options with Tabby - buy now, pay later in 4 installments",
      price: "0% Interest Available",
      highlight: false
    },
    {
      icon: <Truck className="w-12 h-12 text-primary" />,
      title: "Free Delivery",
      description: "Free delivery across Dubai and UAE for all custom PC builds",
      price: "Included with every build",
      highlight: false
    },
    {
      icon: <Headphones className="w-12 h-12 text-primary" />,
      title: "Expert Support",
      description: "24/7 technical support and lifetime consultation on your gaming setup",
      price: "Lifetime included",
      highlight: false
    }
  ];

  const testimonials = [
    {
      name: "Ahmed Al-Rashid",
      location: "Dubai Marina",
      text: "AMZ TECH built me the perfect gaming PC. The performance is incredible and the support has been amazing!",
      rating: 5
    },
    {
      name: "Sarah Johnson", 
      location: "JLT",
      text: "Professional service and great prices. My workstation handles video editing like a dream.",
      rating: 5
    },
    {
      name: "Mohammed Hassan",
      location: "Downtown Dubai",
      text: "Fast delivery, excellent build quality, and the Tabby payment option made it so convenient.",
      rating: 5
    }
  ];

  return (
    <>
      <SEOHead
        title="AMZ TECH - Custom Gaming PC Builds Dubai UAE | Expert PC Building Services"
        description="AMZ TECH specializes in custom gaming PC builds in Dubai, UAE. Get expert PC building services, 360° warranty, free delivery, and best market prices. Build your dream gaming PC today!"
        keywords="Custom PC Builds UAE, Gaming PCs Dubai, Build Gaming PC UAE, Custom Computer Dubai, PC Builder UAE, Gaming Setup Dubai"
        type="website"
        structuredData={LocalBusinessSchema}
      />
      
      <StructuredData schema={OrganizationSchema} id="organization-schema" />
      <StructuredData schema={WebsiteSchema} id="website-schema" />
      <StructuredData schema={ServiceSchema} id="service-schema" />
      
      <div className="min-h-screen">
      {/* Revolutionary Hero Section */}
      <section className="relative min-h-screen pt-20 sm:pt-18 md:pt-20 lg:pt-24 overflow-hidden bg-gradient-to-b from-background via-background/98 to-muted/30">
        {/* Animated Background Grid */}
        <div className="absolute inset-0 bg-gaming-grid opacity-30"></div>
        
        {/* Main Content Grid */}
        <div className="container mx-auto px-4 min-h-[calc(100vh-5rem)] sm:h-[calc(100vh-4.5rem)] md:min-h-[calc(100vh-5rem)] lg:h-[calc(100vh-6rem)] grid grid-cols-1 lg:grid-cols-12 gap-4 md:gap-6 lg:gap-8 items-center relative z-10 py-8 lg:py-0">
          
          {/* Left Content - 5 columns */}
          <div className="md:col-span-1 lg:col-span-5 space-y-4 md:space-y-6 lg:space-y-8 text-center md:text-left order-last md:order-first">
            {/* Animated Badge */}
            <div className="inline-flex items-center gap-2 bg-primary/10 border border-primary/20 rounded-full px-4 py-2 text-sm font-medium text-primary animate-fade-in">
              <Zap className="w-4 h-4" />
              Dubai's #1 PC Building Experts
            </div>
            
            {/* Main Heading with Gradient */}
            <h1 className="text-3xl sm:text-4xl md:text-4xl lg:text-6xl xl:text-7xl font-bold leading-tight">
              <span className="block text-foreground">Build Your</span>
              <span className="block bg-gradient-to-r from-primary via-secondary to-primary bg-clip-text text-transparent animate-fade-in">
                Dream PC
              </span>
            </h1>
            
            {/* Subtitle */}
            <p className="text-base sm:text-lg md:text-base lg:text-2xl text-muted-foreground max-w-2xl leading-relaxed">
              Watch your perfect gaming rig come to life. Premium components, 
              expert assembly, and unmatched performance in Dubai, UAE.
            </p>
            
            {/* Feature Pills */}
            <div className="flex flex-wrap gap-2 md:gap-3 justify-center md:justify-start">
              <div className="flex items-center gap-2 bg-card/50 border border-border rounded-full px-3 md:px-4 py-2 text-xs md:text-sm">
                <Target className="w-3 md:w-4 h-3 md:h-4 text-primary" />
                Custom Built
              </div>
              <div className="flex items-center gap-2 bg-card/50 border border-border rounded-full px-3 md:px-4 py-2 text-xs md:text-sm">
                <Award className="w-3 md:w-4 h-3 md:h-4 text-secondary" />
                360° Warranty
              </div>
              <div className="flex items-center gap-2 bg-card/50 border border-border rounded-full px-3 md:px-4 py-2 text-xs md:text-sm">
                <Truck className="w-3 md:w-4 h-3 md:h-4 text-primary" />
                Free Delivery
              </div>
            </div>
            
            {/* CTA Buttons */}
            <div className="flex flex-col xs:flex-row gap-3 sm:gap-4 justify-center md:justify-start pt-2 lg:pt-4 w-full">
              <Button variant="gaming" size="lg" className="group relative shadow-lg shadow-primary/20 hover:shadow-xl hover:shadow-primary/40 transition-all duration-1000 ease-out animate-[pulse_4s_ease-in-out_infinite] hover:animate-none w-full xs:w-auto flex-1 xs:flex-initial" asChild>
                <Link to="/contact" onClick={handleQuoteRequest}>
                  <MessageCircle className="w-5 h-5 mr-2 group-hover:scale-110 transition-transform duration-800 ease-out" />
                  Get Your Quote
                  {/* Ultra smooth glow overlay */}
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/3 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-1200 ease-out rounded-md"></div>
                </Link>
              </Button>
              <Button 
                variant="gaming-outline" 
                size="lg" 
                className="group hover:shadow-md hover:shadow-primary/15 transition-all duration-800 ease-out w-full xs:w-auto flex-1 xs:flex-initial" 
                asChild
              >
                <Link to="/sample-builds" onClick={() => handleSampleBuildClick('sample_builds', 'various')}>
                  <Cpu className="w-5 h-5 mr-2 group-hover:rotate-6 transition-transform duration-1000 ease-out" />
                  View Sample Builds
                </Link>
              </Button>
            </div>
          </div>
          
          {/* Right Content - 7 columns for 3D Animation */}
          <div className="md:col-span-1 lg:col-span-7 h-[300px] xs:h-[350px] sm:h-[400px] md:h-[450px] lg:h-[700px] relative order-first md:order-last">
            {/* 3D PC Assembly Animation */}
            <div className="w-full h-full rounded-xl lg:rounded-2xl overflow-hidden bg-gradient-to-br from-card/30 to-card/60 border border-border/50 backdrop-blur-sm">
              <PCAssemblyAnimation />
            </div>
            
            {/* Floating Stats - Mobile Optimized */}
            <div className="absolute bottom-2 left-2 sm:-bottom-4 sm:-left-4 lg:-bottom-6 lg:-left-6 bg-card/95 backdrop-blur-sm border border-border rounded-lg lg:rounded-xl p-2 sm:p-3 lg:p-4 animate-fade-in">
              <div className="text-sm sm:text-lg lg:text-2xl font-bold text-primary">500+</div>
              <div className="text-xs sm:text-sm text-muted-foreground">PCs Built</div>
            </div>
            
            <div className="absolute top-2 right-2 sm:-top-4 sm:-right-4 lg:-top-6 lg:-right-6 bg-card/95 backdrop-blur-sm border border-border rounded-lg lg:rounded-xl p-2 sm:p-3 lg:p-4 animate-fade-in">
              <div className="text-sm sm:text-lg lg:text-2xl font-bold text-secondary">24/7</div>
              <div className="text-xs sm:text-sm text-muted-foreground">Support</div>
            </div>
          </div>

          {/* Remove Mobile Stats Row */}
        </div>
      </section>

      {/* Gradient Transition */}
      <div className="h-32 bg-gradient-to-b from-muted/30 via-muted/15 to-background"></div>

      {/* Scroll Indicator - Desktop only */}
      <div className="hidden lg:block relative -mt-24 pb-8 text-center z-10">
        <div className="inline-flex flex-col items-center">
          <div className="w-6 h-10 border-2 border-primary/50 rounded-full flex justify-center animate-pulse bg-background/80 backdrop-blur-sm">
            <div className="w-1 h-3 bg-primary rounded-full mt-2 animate-bounce"></div>
          </div>
          <span className="text-xs text-muted-foreground mt-2">Scroll to explore</span>
        </div>
      </div>

      {/* Why Choose Us Section */}
      <section className="mobile-section bg-gaming-grid">
        <div className="container mx-auto mobile-container">
          <div className="text-center mb-12 lg:mb-16">
            <h2 className="section-header">Why Choose AMZ TECH?</h2>
            <p className="mobile-text-lg sm:text-xl text-muted-foreground mt-4">
              Dubai's trusted custom PC building experts
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {features.map((feature, index) => (
              <Card key={index} className={`gaming-card text-center relative ${feature.highlight ? 'border-secondary glow-card' : ''}`}>
                {feature.highlight && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <div className="bg-gradient-to-r from-secondary to-primary text-primary-foreground px-4 py-1 rounded-full text-sm font-semibold">
                      NEW GUARANTEE
                    </div>
                  </div>
                )}
                <CardContent className="pt-6">
                  <div className="flex justify-center mb-4">
                    {feature.icon}
                  </div>
                  <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
                  <p className="text-muted-foreground mb-4">{feature.description}</p>
                  <div className={`inline-block px-3 py-1 rounded-full text-sm font-semibold ${
                    feature.highlight 
                      ? 'bg-secondary/10 text-secondary border border-secondary/30' 
                      : 'bg-primary/10 text-primary border border-primary/30'
                  }`}>
                    {feature.price}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="mobile-section bg-gaming-grid">
        <div className="container mx-auto mobile-container">
          <div className="text-center mb-12 lg:mb-16">
            <h2 className="section-header">What Our Clients Say</h2>
            <p className="mobile-text-lg sm:text-xl text-muted-foreground mt-4">
              Trusted by gamers and professionals across Dubai
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="gaming-card">
                <CardContent className="pt-6">
                  <div className="flex justify-center mb-4">
                    <Quote className="w-8 h-8 text-primary" />
                  </div>
                  <div className="flex justify-center mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 text-yellow-500 fill-current" />
                    ))}
                  </div>
                  <p className="text-center text-muted-foreground mb-4">
                    "{testimonial.text}"
                  </p>
                  <div className="text-center">
                    <p className="font-semibold">{testimonial.name}</p>
                    <p className="text-sm text-muted-foreground">{testimonial.location}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="mobile-section">
        <div className="container mx-auto mobile-container text-center">
          <h2 className="section-header mb-6 lg:mb-8">Ready to Game?</h2>
          <p className="mobile-text-lg sm:text-xl text-muted-foreground mb-6 lg:mb-8 max-w-2xl mx-auto">
            Get your custom gaming PC quote today. Free delivery, premium components, 
            and professional support in Dubai.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button variant="gaming" size="lg" asChild>
              <a 
                href="https://api.whatsapp.com/send?phone=971564689006&text=Hi%2C%20I%27m%20interested%20in%20a%20custom%20gaming%20PC%20build"
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center"
              >
                <MessageCircle className="w-5 h-5 mr-2" />
                WhatsApp Quote
              </a>
            </Button>
            <Button variant="gaming-outline" size="lg" asChild>
              <Link to="/contact#quote-form" className="flex items-center">
                <Mail className="w-5 h-5 mr-2" />
                Email Quote
              </Link>
            </Button>
          </div>
        </div>
       </section>
     </div>
    </>
  );
};

export default Home;