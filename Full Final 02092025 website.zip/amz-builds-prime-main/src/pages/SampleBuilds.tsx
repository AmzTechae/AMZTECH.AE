import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

const SampleBuilds = () => {
  const sampleBuilds = [
    {
      title: "Budget Build",
      subtitle: "Entry-level Gaming PC",
      specs: [
        "AMD Ryzen 5 5600G or Intel i5",
        "16GB DDR4 RAM",
        "GTX 1660 Super / RTX 3060",
        "500GB NVMe SSD",
        "B450/B550 Motherboard",
        "500W 80+ Bronze PSU"
      ],
      features: [
        "1080p Gaming at 60+ FPS",
        "Perfect for Esports titles",
        "Streaming capable",
        "Upgradeable design"
      ]
    },
    {
      title: "Mid-Range Build",
      subtitle: "Balanced Gaming/Editing PC",
      specs: [
        "AMD Ryzen 7 5700X or Intel i7",
        "32GB DDR4 RAM",
        "RTX 4060 Ti / RTX 4070",
        "1TB NVMe SSD",
        "X570/B550 Motherboard",
        "650W 80+ Gold PSU"
      ],
      features: [
        "1440p Gaming at 60+ FPS",
        "Content creation ready",
        "Ray tracing support",
        "Premium build quality"
      ]
    },
    {
      title: "High-End Build",
      subtitle: "Premium Performance PC",
      specs: [
        "AMD Ryzen 9 7900X or Intel i9",
        "32GB DDR5 RAM",
        "RTX 4080 / RTX 4090",
        "2TB NVMe SSD",
        "X670/Z790 Motherboard", 
        "850W 80+ Platinum PSU"
      ],
      features: [
        "4K Gaming at 60+ FPS",
        "Professional workstation",
        "Custom water cooling",
        "RGB lighting system"
      ]
    }
  ];

  return (
    <div className="min-h-screen pt-16">
      {/* Hero Section */}
      <section className="py-20 bg-gaming-grid">
        <div className="container mx-auto px-4 text-center">
          <h1 className="section-header mb-6">Sample PC Builds</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Choose from our popular configurations or get a custom quote tailored to your specific needs and budget
          </p>
        </div>
      </section>

      {/* Sample Builds Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {sampleBuilds.map((build, index) => (
              <Card key={index} className="gaming-card">
                <CardContent className="p-6">
                  <div className="mb-4">
                    <h3 className="text-2xl font-bold text-neon">{build.title}</h3>
                    <p className="text-muted-foreground">{build.subtitle}</p>
                  </div>
                  
                  <div className="mb-4">
                    <h4 className="font-semibold mb-2">Specifications:</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      {build.specs.map((spec, i) => (
                        <li key={i}>• {spec}</li>
                      ))}
                    </ul>
                  </div>

                  <div className="mb-6">
                    <h4 className="font-semibold mb-2">Features:</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      {build.features.map((feature, i) => (
                        <li key={i}>• {feature}</li>
                      ))}
                    </ul>
                  </div>

                  <Button variant="gaming" className="w-full" asChild>
                    <Link to="/contact">Request Quote</Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>


      {/* CTA Section */}
      <section className="py-20 bg-gaming-grid">
        <div className="container mx-auto px-4 text-center">
          <h2 className="section-header mb-8">Need Something Custom?</h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Don't see exactly what you're looking for? Let us build a custom PC tailored to your specific requirements and budget.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button variant="gaming" size="lg" asChild>
            <a 
              href="https://api.whatsapp.com/send?phone=971564689006&text=Hi%2C%20I%27m%20interested%20in%20a%20custom%20gaming%20PC%20build"
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center"
            >
              WhatsApp Quote
            </a>
          </Button>
            <Button variant="gaming-outline" size="lg" asChild>
              <Link to="/contact#quote-form">
                Email Quote
              </Link>
            </Button>
            <Button variant="gaming-outline" size="lg" asChild>
              <Link to="/faq">
                FAQ
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default SampleBuilds;